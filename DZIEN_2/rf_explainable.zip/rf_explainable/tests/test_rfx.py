"""Testy poprawności: porównanie ze scikit-learn i tożsamości wyjaśnień.

Uruchomienie:  python -m pytest -q
"""
import sys
from pathlib import Path

import numpy as np
import pytest
from sklearn.tree import DecisionTreeClassifier

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rfx import DecisionTree, RandomForest, Tracer, explain, gini, metrics  # noqa: E402
from rfx.data import load_data  # noqa: E402


@pytest.fixture(scope="module")
def D():
    return load_data()


@pytest.fixture(scope="module")
def forest(D):
    tr = Tracer(detail_trees=[0, 1])
    rf = RandomForest(n_estimators=40, random_state=1).fit(
        D["X_train"], D["y_train"], D["feature_names"], tracer=tr)
    return rf, tr


def test_gini():
    assert gini([5, 0]) == 0
    assert gini([5, 5]) == pytest.approx(0.5)


def test_tree_matches_sklearn_structure(D):
    ours = DecisionTree().fit(D["X_train"], D["y_train"])
    sk = DecisionTreeClassifier(random_state=0).fit(D["X_train"], D["y_train"])
    assert len(ours.nodes_) == sk.tree_.node_count
    assert ours.depth_ == sk.get_depth()
    assert ours.nodes_[0].feature == sk.tree_.feature[0]
    assert np.corrcoef(ours.feature_importances_, sk.feature_importances_)[0, 1] > 0.99


def test_forest_quality(D, forest):
    rf, _ = forest
    p = rf.predict_proba(D["X_test"])[:, 1]
    assert metrics.roc_auc(D["y_test"], p) > 0.95
    assert rf.oob_score_ > 0.9


def test_saabas_identity(D, forest):
    rf, _ = forest
    for x in D["X_test"][:10]:
        bias, contrib, _, p = explain.forest_contributions(rf, x)
        assert bias + contrib.sum() == pytest.approx(rf.predict_proba(x[None])[0, 1])


def test_mdi_reconstructed_from_log(forest):
    rf, tr = forest
    mdi = explain.mdi_from_log(tr, rf.n_features_, rf.n_estimators)
    assert np.allclose(mdi, rf.feature_importances_, atol=1e-5)


def test_log_contents(forest):
    rf, tr = forest
    c = tr.counts()
    assert c["bootstrap"] == c["tree_done"] == rf.n_estimators
    assert c["node_split"] == sum(len(t.nodes_) - t.n_leaves_ for t in rf.trees_)
    assert "candidates" in tr.filter("node_split", tree_id=0)[0]
    assert "candidates" not in tr.filter("node_split", tree_id=5)[0]


def test_node_data_matches_log(forest):
    rf, tr = forest
    for e in tr.filter("node_split", tree_id=0)[:5]:
        Xn, yn = explain.node_data(rf, 0, e["node_id"])
        assert len(yn) == e["n"]
        assert list(np.bincount(yn, minlength=2)) == e["counts"]


def test_roc_auc_matches_sklearn(D, forest):
    from sklearn.metrics import roc_auc_score
    rf, _ = forest
    p = rf.predict_proba(D["X_test"])[:, 1]
    assert metrics.roc_auc(D["y_test"], p) == pytest.approx(roc_auc_score(D["y_test"], p))
