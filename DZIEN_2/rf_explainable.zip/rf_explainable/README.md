# Random Forest bez czarnej skrzynki

Random Forest napisany od podstaw w NumPy, z dziennikiem decyzji (JSONL), własnymi metrykami
i wizualizacjami wyjaśniającymi. Dane: **Breast Cancer Wisconsin (Diagnostic)**.

Dwie wersje, jedna logika:

| wersja | plik | dla kogo |
|---|---|---|
| Notebook Jupyter | `RandomForest_krok_po_kroku.ipynb` | wykład / samodzielna nauka: kod algorytmu w komórkach, narracja krok po kroku, ćwiczenia |
| Aplikacja www | `app.py` (Streamlit) | warsztat / demo: suwaki hiperparametrów, przeglądarka logów, „co jeśli?” dla pacjentki |

## Uruchomienie

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# aplikacja www → otworzy się http://localhost:8501
streamlit run app.py

# notebook
jupyter notebook RandomForest_krok_po_kroku.ipynb

# testy poprawności (porównanie ze scikit-learn, tożsamości wyjaśnień)
python -m pytest -q
```

Notebook jest **samowystarczalny** (cały kod jest w komórkach), więc działa też w Google Colab.
Został wygenerowany z kodu pakietu `rfx` (`python tools/build_notebook.py --execute`),
więc logika w obu wersjach jest identyczna.

## Struktura

```
rfx/
  tracer.py    dziennik zdarzeń (JSON Lines)
  tree.py      CART: Gini, skan progów, losowanie cech, logi node_split / leaf
  forest.py    bootstrap, OOB, głosowanie, logi bootstrap / tree_done / oob_progress / predict
  metrics.py   macierz pomyłek, czułość, precyzja, swoistość, ROC, AUC – od podstaw
  explain.py   MDI z logu, permutacja OOB (Breiman), dekompozycja Saabasa, marginesy,
               niezgoda drzew, stabilność pojedynczego drzewa, opisy w języku naturalnym
  viz.py       wykresy (matplotlib)
  data.py      wczytanie danych (1 = złośliwy!) i podział warstwowy
app.py         aplikacja Streamlit
tests/         testy
tools/         generator notebooka
```

## Co jest logowane

| zdarzenie | kiedy | najważniejsze pola |
|---|---|---|
| `forest_start` | start | parametry, liczność klas, liczba cech losowanych w węźle |
| `bootstrap` | każde drzewo | liczba unikalnych próbek, liczba OOB, (szczegółowo: indeksy OOB) |
| `node_split` | każdy podział | cecha, próg, spadek Gini, ważony zysk, n lewo/prawo; dla drzew szczegółowych: **wszyscy kandydaci** z progami i zyskami |
| `leaf` | każdy liść | rozkład klas, P(złośliwy), **powód zatrzymania** |
| `tree_done` | koniec drzewa | rozmiar, głębokość, cecha w korzeniu, dokładność OOB drzewa |
| `oob_progress` | po każdym drzewie | błąd OOB lasu |
| `predict` | `predict_logged()` | P, głosy twarde, P każdego drzewa, margines |

## Gwarancje (sprawdzane w testach)

* klasyczne drzewo (`max_features=None`) ma tę samą strukturę co `sklearn.tree.DecisionTreeClassifier`,
* **MDI odtworzone wyłącznie z logu** = MDI z modelu,
* dekompozycja Saabasa jest dokładna: `bias + Σ wkładów = predict_proba`,
* dane w węźle odtworzone z bootstrapu zgadzają się z liczbami w logu,
* własne ROC AUC = `sklearn.metrics.roc_auc_score`.

## Uwaga

Materiał dydaktyczny – model nie jest narzędziem diagnostycznym.
