"""Random Forest bez czarnej skrzynki – aplikacja www (Streamlit).

Uruchomienie:
    pip install -r requirements.txt
    streamlit run app.py
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from rfx import RandomForest, DecisionTree, Tracer, explain, metrics, viz
from rfx.data import load_data

st.set_page_config(page_title="Random Forest bez czarnej skrzynki", page_icon="🌳",
                   layout="wide")


def show(fig):
    st.pyplot(fig, width="stretch")
    plt.close(fig)


# ==========================================================================
# Panel boczny – hiperparametry
# ==========================================================================
st.sidebar.title("🌳 Parametry")
test_size = st.sidebar.slider("Udział zbioru testowego", 0.15, 0.40, 0.25, 0.05)
split_seed = st.sidebar.number_input("Ziarno podziału train/test", 0, 9999, 42)
n_estimators = st.sidebar.slider("Liczba drzew (n_estimators)", 5, 300, 100, 5)
mf_choice = st.sidebar.selectbox(
    "Cech losowanych w węźle (max_features)",
    ["sqrt (√30 = 5)", "log2 (4)", "1", "2", "10", "wszystkie (bagging)"])
max_features = {"sqrt (√30 = 5)": "sqrt", "log2 (4)": "log2", "1": 1, "2": 2, "10": 10,
                "wszystkie (bagging)": None}[mf_choice]
max_depth = st.sidebar.slider("Maks. głębokość (0 = bez limitu)", 0, 15, 0)
min_samples_leaf = st.sidebar.slider("Min. próbek w liściu", 1, 20, 1)
seed = st.sidebar.number_input("Ziarno lasu (random_state)", 0, 9999, 0)
n_detail = st.sidebar.slider("Drzewa z pełnym śladem kandydatów", 1, 10, 3,
                             help="Dla tych drzew log zawiera wszystkie wylosowane cechy "
                                  "i ich najlepsze progi w każdym węźle.")
st.sidebar.caption("Zmiana parametru = ponowne uczenie (wyniki są buforowane).")

PARAMS = (test_size, int(split_seed), n_estimators, max_features,
          None if max_depth == 0 else max_depth, min_samples_leaf, int(seed), n_detail)


# ==========================================================================
# Obliczenia (buforowane)
# ==========================================================================
@st.cache_data
def get_data(test_size, split_seed):
    return load_data(test_size=test_size, random_state=split_seed)


@st.cache_resource(show_spinner="Uczę las i zapisuję dziennik decyzji…")
def train(params):
    test_size, split_seed, T, mf, md, msl, seed, n_detail = params
    D = get_data(test_size, split_seed)
    tracer = Tracer(detail_trees=range(n_detail))
    rf = RandomForest(n_estimators=T, max_features=mf, max_depth=md,
                      min_samples_leaf=msl, random_state=seed)
    rf.fit(D["X_train"], D["y_train"], feature_names=D["feature_names"], tracer=tracer)
    return rf, tracer


@st.cache_data(show_spinner="Liczę ważność permutacyjną OOB…")
def get_perm(params):
    rf, _ = train(params)
    return explain.permutation_importance_oob(rf, n_repeats=3)


@st.cache_data(show_spinner="Uczę modele porównawcze…")
def get_comparison(params):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    test_size, split_seed, T, mf, md, msl, seed, _ = params
    D = get_data(test_size, split_seed)
    rf, _ = train(params)
    Xtr, ytr, Xte = D["X_train"], D["y_train"], D["X_test"]
    single = DecisionTree(max_depth=md, min_samples_leaf=msl).fit(Xtr, ytr)
    return {
        "RF – nasz": rf.predict_proba(Xte)[:, 1],
        "RF – scikit-learn": RandomForestClassifier(
            T, max_features=mf, max_depth=md, min_samples_leaf=msl,
            random_state=seed).fit(Xtr, ytr).predict_proba(Xte)[:, 1],
        "Pojedyncze drzewo": single.predict_proba(Xte)[:, 1],
        "Regresja logistyczna": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
        .fit(Xtr, ytr).predict_proba(Xte)[:, 1],
    }


@st.cache_data(show_spinner="Uczę pojedyncze drzewa na kolejnych bootstrapach…")
def get_stability(params, n_runs):
    test_size, split_seed, *_ = params
    D = get_data(test_size, split_seed)
    md = params[4]
    return explain.single_tree_stability(D["X_train"], D["y_train"], D["X_test"], D["y_test"],
                                         D["feature_names"], n_runs=n_runs, max_depth=md)


D = get_data(test_size, int(split_seed))
names = D["feature_names"]
CN = D["class_names"]
rf, tracer = train(PARAMS)
X_test, y_test = D["X_test"], D["y_test"]
p_test = rf.predict_proba(X_test)[:, 1]
margins = explain.vote_margins(rf, X_test, y_test)

# ==========================================================================
# Nagłówek
# ==========================================================================
st.title("Random Forest bez czarnej skrzynki")
st.caption("Breast Cancer Wisconsin (Diagnostic) · las napisany od podstaw w NumPy · "
           "każda decyzja zapisana w dzienniku JSONL")
rep = metrics.binary_report(y_test, (p_test >= 0.5).astype(int))
c = st.columns(5)
c[0].metric("Dokładność OOB", f"{rf.oob_score_:.3f}")
c[1].metric("Dokładność (test)", f"{rep['accuracy']:.3f}")
c[2].metric("Czułość – złośliwe", f"{rep['recall']:.3f}")
c[3].metric("ROC AUC (test)", f"{metrics.roc_auc(y_test, p_test):.3f}")
c[4].metric("Zdarzeń w dzienniku", f"{len(tracer.events):,}".replace(",", " "))

tabs = st.tabs(["📊 Dane", "🌱 Trening krok po kroku", "🌳 Anatomia drzewa",
                "🩺 Predykcja pacjentki", "🔎 Ważność cech", "✅ Ocena i porównanie",
                "❓ Dlaczego Random Forest?"])

# ==========================================================================
# 1. Dane
# ==========================================================================
with tabs[0]:
    st.subheader("Zbiór danych")
    st.markdown(
        f"""
**569 biopsji cienkoigłowych**, 30 cech: 10 pomiarów jądra komórkowego (promień, tekstura,
obwód, pole, gładkość, zwartość, wklęsłość, punkty wklęsłe, symetria, wymiar fraktalny), każdy jako
`mean`, `error` (błąd standardowy) i `worst` (najgorsza wartość).

Podział warstwowy: **{len(D['y_train'])}** próbek treningowych, **{len(y_test)}** testowych,
odsetek złośliwych: {D['y_train'].mean():.1%} / {y_test.mean():.1%}.

> ⚠️ W scikit-learn `target = 0` to *malignant*. Odwracamy etykiety: **1 = złośliwy** (klasa
> pozytywna), więc *czułość* = odsetek wykrytych nowotworów złośliwych.
""")
    col1, col2 = st.columns([1, 1])
    with col1:
        fx = st.selectbox("Cecha na osi X", names, index=names.index("worst radius"))
        fy = st.selectbox("Cecha na osi Y", names, index=names.index("worst concave points"))
        fig, ax = plt.subplots(figsize=(6, 4.6))
        for cls, col in [(0, viz.BENIGN), (1, viz.MALIGNANT)]:
            m = D["y"] == cls
            ax.scatter(D["X"][m, names.index(fx)], D["X"][m, names.index(fy)], s=14,
                       color=col, alpha=0.7, label=CN[cls], edgecolor="none")
        ax.set_xlabel(fx)
        ax.set_ylabel(fy)
        ax.legend()
        ax.set_title("Dwie cechy, dwie klasy")
        show(fig)
    with col2:
        df = pd.DataFrame(D["X_train"], columns=names)
        df["klasa"] = [CN[v] for v in D["y_train"]]
        st.dataframe(df.groupby("klasa").mean().T.round(4), height=480)

# ==========================================================================
# 2. Trening
# ==========================================================================
with tabs[1]:
    st.subheader("Co działo się podczas uczenia?")
    st.markdown(
        "Każde drzewo dostaje **próbkę bootstrap** (losowanie ze zwracaniem). Próbki, które nie "
        "zostały wylosowane (**OOB**, ok. 36,8%), służą drzewu jako zbiór walidacyjny. "
        "W każdym węźle drzewo **losuje podzbiór cech** i wybiera najlepszy podział spośród nich.")
    col1, col2 = st.columns(2)
    with col1:
        t_boot = st.slider("Drzewo (bootstrap)", 0, rf.n_estimators - 1, 0)
        show(viz.plot_bootstrap(rf.inbag_counts_, t_boot))
    with col2:
        acc_curve = explain.accuracy_vs_n_trees(rf, X_test, y_test)
        sc = explain.tree_strength_and_correlation(rf, X_test, y_test)
        show(viz.plot_oob_curve(rf, acc_curve, 1 - sc["mean_tree_accuracy"]))

    st.markdown("#### Podsumowanie drzew (zdarzenia `tree_done`)")
    st.dataframe(pd.DataFrame(tracer.filter("tree_done")).drop(columns=["seq", "event"]),
                 height=260, width="stretch")

    st.markdown("#### Przeglądarka dziennika")
    counts = tracer.counts()
    st.caption(" · ".join(f"`{k}`: {v}" for k, v in counts.items()))
    cc = st.columns([2, 1, 1])
    ev_types = cc[0].multiselect("Typy zdarzeń", list(counts), default=["node_split"])
    tree_f = cc[1].number_input("Drzewo (−1 = wszystkie)", -1, rf.n_estimators - 1, 0)
    limit = cc[2].number_input("Maks. wierszy", 10, 5000, 200, 10)
    evs = [e for e in tracer.events if e["event"] in ev_types
           and (tree_f < 0 or e.get("tree_id", tree_f) == tree_f)][: int(limit)]
    if evs:
        df = pd.DataFrame(evs)
        if "candidates" in df:
            df["candidates"] = df["candidates"].apply(
                lambda cs: ", ".join(f"{c['name']}:{c['gain']:.3f}" for c in cs
                                     if c["gain"] is not None) if isinstance(cs, list) else "")
        for col in df.columns:
            if df[col].apply(lambda v: isinstance(v, list)).any():
                df[col] = df[col].astype(str)
        st.dataframe(df, height=320, width="stretch")
    st.download_button("⬇️ Pobierz pełny dziennik (JSONL)", tracer.to_jsonl(),
                       file_name="rf_trace.jsonl", mime="application/json")

# ==========================================================================
# 3. Anatomia drzewa
# ==========================================================================
with tabs[2]:
    st.subheader("Dlaczego drzewo podzieliło dane właśnie tak?")
    col1, col2 = st.columns([1, 3])
    with col1:
        t_id = st.number_input("Numer drzewa", 0, rf.n_estimators - 1, 0)
        depth_show = st.slider("Pokaż do głębokości", 1, 6, 3)
        tree = rf.trees_[t_id]
        st.caption(f"węzłów: {len(tree.nodes_)}, liści: {tree.n_leaves_}, "
                   f"głębokość: {tree.depth_}")
        splits = tracer.filter("node_split", tree_id=t_id)
        labels = {e["node_id"]: f"#{e['node_id']} (gł. {e['depth']}): {e['name']} ≤ {e['threshold']:.4g}"
                  for e in splits}
        node_id = st.selectbox("Węzeł", list(labels), format_func=labels.get) if labels else None
    with col2:
        show(viz.plot_tree(tree, names, max_depth=depth_show))

    if node_id is not None:
        ev = next(e for e in splits if e["node_id"] == node_id)
        st.info(explain.explain_node_text(ev))
        if "candidates" in ev:
            col1, col2 = st.columns([2, 3])
            with col1:
                show(viz.plot_split_candidates(ev))
            with col2:
                Xn, yn = explain.node_data(rf, t_id, node_id)
                feats = [c["feature"] for c in ev["candidates"]][:9]
                show(viz.plot_gini_scan(Xn, yn, feats, names, chosen=ev["feature"],
                                        parent_gini=ev["gini"]))
        else:
            st.warning(f"Pełna lista kandydatów jest zapisywana tylko dla drzew 0–{n_detail - 1}. "
                       "Zwiększ „Drzewa z pełnym śladem” w panelu bocznym.")
            Xn, yn = explain.node_data(rf, t_id, node_id)
            show(viz.plot_gini_scan(Xn, yn, [ev["feature"]], names, chosen=ev["feature"],
                                    parent_gini=ev["gini"]))
        leaves = tracer.filter("leaf", tree_id=t_id)
        with st.expander(f"Liście tego drzewa ({len(leaves)}) i powody zatrzymania"):
            st.dataframe(pd.DataFrame(leaves)[["node_id", "depth", "n", "counts", "proba", "reason"]]
                         .astype({"counts": str, "proba": str}), width="stretch")

# ==========================================================================
# 4. Predykcja pacjentki
# ==========================================================================
with tabs[3]:
    st.subheader("Wyjaśnienie decyzji dla jednej pacjentki")
    wrong = np.flatnonzero((p_test >= 0.5).astype(int) != y_test)
    presets = {
        "wybór ręczny": None,
        "najbardziej niepewna (P≈0,5)": int(np.argmin(np.abs(p_test - 0.5))),
        "jednoznacznie złośliwa": int(np.argmax(np.where(y_test == 1, margins, -9))),
        "jednoznacznie łagodna": int(np.argmax(np.where(y_test == 0, margins, -9))),
    }
    if len(wrong):
        presets["błędnie sklasyfikowana (najgorszy margines)"] = int(wrong[np.argmin(margins[wrong])])
    col1, col2 = st.columns([1, 2])
    with col1:
        preset = st.radio("Szybki wybór", list(presets), index=1)
        default_i = presets[preset] if presets[preset] is not None else 0
        i = st.selectbox(
            "Pacjentka ze zbioru testowego", range(len(y_test)), index=default_i,
            format_func=lambda k: f"#{k} – prawdziwa: {CN[y_test[k]]}, P(zł)={p_test[k]:.2f}",
            disabled=presets[preset] is not None)
        if presets[preset] is not None:
            i = presets[preset]
    x = X_test[i].copy()

    with st.expander("🔧 Co jeśli? – zmień wartości najważniejszych cech"):
        top6 = list(np.argsort(-rf.feature_importances_)[:6])
        cols = st.columns(3)
        for k, j in enumerate(top6):
            lo, hi = float(D["X"][:, j].min()), float(D["X"][:, j].max())
            x[j] = cols[k % 3].slider(names[j], lo, hi, float(X_test[i, j]),
                                      key=f"wf_{i}_{j}_{PARAMS}")
        if not np.allclose(x, X_test[i]):
            st.caption("Wyjaśnienie poniżej dotyczy **zmodyfikowanej** pacjentki.")

    bias, contrib, _, p = explain.forest_contributions(rf, x)
    votes = rf.hard_votes(x[None])[0]
    with col2:
        m = st.columns(3)
        m[0].metric("Predykcja lasu", CN[int(p >= 0.5)].upper())
        m[0].caption(f"P(złośliwy) = {p:.3f}")
        m[1].metric("Głosy drzew (zł / łag)", f"{votes[1]} / {votes[0]}")
        m[2].metric("Prawdziwa diagnoza", CN[y_test[i]].upper())
        st.success(explain.explain_prediction_text(rf, x, names))
        st.caption(f"Kontrola dekompozycji: bias {bias:.4f} + Σ wkładów {contrib.sum():+.4f} = "
                   f"{p:.4f} = predict_proba ({rf.predict_proba(x[None])[0, 1]:.4f})")

    col1, col2 = st.columns(2)
    with col1:
        show(viz.plot_waterfall(bias, contrib, names, x))
    with col2:
        show(viz.plot_tree_votes(rf.tree_probas(x[None])[:, 0, 1]))

    st.markdown("#### Ścieżki w poszczególnych drzewach")
    pt = pd.DataFrame(explain.path_table(rf, x))
    st.dataframe(pt, height=260, width="stretch")
    cc = st.columns(2)
    t_draw = cc[0].number_input("Narysuj ścieżkę w drzewie nr", 0, rf.n_estimators - 1, 0,
                                key="t_draw")
    d_draw = cc[1].slider("Głębokość rysunku", 1, 8, 4, key="d_draw")
    tr_ = rf.trees_[t_draw]
    show(viz.plot_tree(tr_, names, max_depth=min(d_draw, tr_.depth_),
                       highlight_path=tr_.decision_path(x),
                       title=f"Ścieżka pacjentki #{i} w drzewie #{t_draw}"))

# ==========================================================================
# 5. Ważność cech
# ==========================================================================
with tabs[4]:
    st.subheader("Które cechy decydują globalnie?")
    st.markdown(
        "**MDI** – suma ważonych spadków Gini z podziałów na danej cesze, **odtworzona wyłącznie "
        "z dziennika** `node_split`. **Permutacyjna OOB** (Breiman) – o ile spada dokładność "
        "drzewa na jego próbkach OOB po wymieszaniu wartości cechy.")
    mdi_log = explain.mdi_from_log(tracer, len(names), rf.n_estimators)
    perm, perm_err = get_perm(PARAMS)
    top_k = st.slider("Liczba cech", 5, 30, 15)
    show(viz.plot_importances(names, mdi_log, perm, perm_err, top_k=top_k))
    st.caption(f"Maks. różnica MDI z dziennika vs z modelu: "
               f"{np.abs(mdi_log - rf.feature_importances_).max():.2e}")
    col1, col2 = st.columns([3, 2])
    with col1:
        top = list(np.argsort(-mdi_log)[:10])
        show(viz.plot_correlation(D["X_train"], names, top))
    with col2:
        st.markdown(
            """
**Pułapka korelacji.** `radius`, `perimeter` i `area` są niemal liniowo zależne (r ≈ 0,99).

* MDI rozdziela zasługę między nie dość przypadkowo – zależnie od tego, która trafiła do
  losowania w danym węźle.
* Permutacja jednej z nich szkodzi mało, bo pozostałe niosą tę samą informację.

Ważność cechy w modelu **nie jest** dowodem jej znaczenia przyczynowego.
""")
        st.dataframe(pd.DataFrame({"cecha": names, "MDI": mdi_log, "perm. OOB": perm})
                     .sort_values("MDI", ascending=False).round(4), height=300,
                     width="stretch")

# ==========================================================================
# 6. Ocena
# ==========================================================================
with tabs[5]:
    st.subheader("Ocena na zbiorze testowym – metryki liczone od podstaw")
    models = get_comparison(PARAMS)
    thr = st.slider("Próg decyzji: „złośliwy”, gdy P(złośliwy) ≥", 0.05, 0.95, 0.50, 0.05)
    results, curves = {}, {}
    for nm, pp in models.items():
        r = metrics.binary_report(y_test, (pp >= thr).astype(int))
        r["auc"] = metrics.roc_auc(y_test, pp)
        results[nm] = r
        f, t, _ = metrics.roc_curve(y_test, pp)
        curves[nm] = (f, t, r["auc"])
    st.dataframe(pd.DataFrame(results).T[["accuracy", "recall", "precision", "specificity",
                                          "f1", "auc", "FN", "FP"]].round(3),
                 width="stretch")
    col1, col2, col3 = st.columns([2, 3, 3])
    with col1:
        show(viz.plot_confusion(metrics.confusion_matrix(y_test, (p_test >= thr).astype(int)),
                                title=f"RF (nasz), próg {thr:.2f}"))
    with col2:
        show(viz.plot_roc(curves))
    with col3:
        show(viz.plot_threshold(metrics.threshold_table(y_test, p_test,
                                                        np.linspace(0.05, 0.95, 37))))
    st.markdown("**Przeoczony nowotwór złośliwy (FN)** jest zwykle groźniejszy niż fałszywy "
                "alarm (FP) – dlatego próg 0,5 nie musi być właściwy.")
    col1, col2 = st.columns([3, 2])
    with col1:
        show(viz.plot_margins(margins))
    with col2:
        wrong = np.flatnonzero((p_test >= 0.5).astype(int) != y_test)
        st.markdown("**Błędy lasu (próg 0,5)**")
        st.dataframe(pd.DataFrame({"pacjentka": wrong, "prawdziwa": [CN[c] for c in y_test[wrong]],
                                   "P(złośliwy)": p_test[wrong].round(3),
                                   "margines": margins[wrong].round(2)}),
                     width="stretch")

# ==========================================================================
# 7. Dlaczego Random Forest?
# ==========================================================================
with tabs[6]:
    st.subheader("Dlaczego las, a nie jedno drzewo? I kiedy coś prostszego?")
    n_runs = st.slider("Liczba pojedynczych drzew uczonych na bootstrapach", 10, 100, 30, 10)
    stab = get_stability(PARAMS, n_runs)
    sdf = pd.DataFrame(stab)
    sc = explain.tree_strength_and_correlation(rf, X_test, y_test)
    m = st.columns(4)
    m[0].metric("Pojedyncze drzewo: dokładność", f"{sdf.test_accuracy.mean():.3f}",
                f"± {sdf.test_accuracy.std():.3f} (odch. std)", delta_color="off")
    m[1].metric("Drzewo z lasu: dokładność", f"{sc['mean_tree_accuracy']:.3f}")
    m[2].metric("Cały las: dokładność", f"{(rf.predict(X_test) == y_test).mean():.3f}")
    m[3].metric("Niezgoda dwóch drzew lasu", f"{sc['mean_disagreement']:.3f}")
    col1, col2 = st.columns([3, 2])
    with col1:
        show(viz.plot_root_features(explain.root_feature_counts(rf), stab))
    with col2:
        T = min(40, rf.n_estimators)
        show(viz.plot_disagreement(sc["disagreement_matrix"][:T, :T]))
    st.markdown(
        """
**Wnioski**
1. **Pojedyncze drzewo ma dużą wariancję** – niewielka zmiana danych zmienia cechę w korzeniu
   i dokładność. Trudno ufać modelowi, który „przeskakuje”.
2. **Drzewa w lesie są pojedynczo słabsze** (losowe cechy), ale **mylą się w różnych
   miejscach** – uśrednienie znosi błędy (Breiman: siła ↑, korelacja ↓).
3. **OOB** daje uczciwą walidację bez osobnego zbioru, a **dziennik + dekompozycja Saabasa**
   wyjaśniają każdą decyzję – las przestaje być czarną skrzynką.
4. **Uczciwie:** regresja logistyczna osiąga tu podobne lub lepsze wyniki (dane są prawie
   liniowo separowalne). Wybór modelu w medycynie to kompromis: AUC, kalibracja, czułość,
   koszt FN i to, czy model da się wytłumaczyć klinicystom.

**Do eksperymentu:** ustaw w panelu bocznym `max_features = wszystkie (bagging)` lub `1` i
obserwuj niezgodę drzew, błąd OOB oraz rozkład cech w korzeniach.
""")
