"""Wizualizacje wyjaśniające (matplotlib).

Kolory mają stałe znaczenie we wszystkich wykresach:
  niebieski  = łagodny / przesunięcie w stronę „łagodny”,
  pomarańcz  = złośliwy / przesunięcie w stronę „złośliwy”,
  szary      = kontekst (kandydaci, którzy przegrali, tło).
"""
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, to_rgb
from matplotlib.patches import FancyBboxPatch

BENIGN = "#2a78d6"
MALIGNANT = "#eb6834"
NEUTRAL = "#a3a29c"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e6e5e1"
SURFACE = "#fcfcfb"
AQUA = "#1baf7a"
VIOLET = "#4a3aa7"

DIVERGING = LinearSegmentedColormap.from_list("bm", [BENIGN, "#f0efec", MALIGNANT])


def setup_style():
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.edgecolor": GRID, "axes.labelcolor": INK2, "axes.titlecolor": INK,
        "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
        "axes.labelsize": 10, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
        "axes.spines.top": False, "axes.spines.right": False,
        "xtick.color": INK2, "ytick.color": INK2, "xtick.labelsize": 9, "ytick.labelsize": 9,
        "legend.frameon": False, "legend.fontsize": 9, "font.size": 10,
        "lines.linewidth": 2, "figure.dpi": 110, "axes.axisbelow": True,
    })


setup_style()


def _mix(p):
    """Kolor węzła: od niebieskiego (P=0) do pomarańczowego (P=1), rozjaśniony."""
    b, m = np.array(to_rgb(BENIGN)), np.array(to_rgb(MALIGNANT))
    c = (1 - p) * b + p * m
    return tuple(0.55 * c + 0.45 * np.ones(3))


def _short(name, n=22):
    return name if len(name) <= n else name[: n - 1] + "…"


# ==========================================================================
# Drzewo
# ==========================================================================
def plot_tree(tree, feature_names, max_depth=3, highlight_path=None, title=None,
              show_ids=True):
    """Rysuje drzewo do głębokości max_depth. Głębsze poddrzewa → „⋯”.

    highlight_path – lista id węzłów (np. ścieżka jednej pacjentki).
    """
    nodes = tree.nodes_
    hp = set(highlight_path or [])
    pos, order = {}, []

    def layout(i):
        nd = nodes[i]
        if nd.is_leaf or nd.depth >= max_depth:
            pos[i] = (len(order), -nd.depth)
            order.append(i)
            return pos[i][0]
        xl = layout(nd.left)
        xr = layout(nd.right)
        pos[i] = ((xl + xr) / 2, -nd.depth)
        return pos[i][0]

    layout(0)
    n_leaves = len(order)
    depth_shown = max(-p[1] for p in pos.values())
    fig, ax = plt.subplots(figsize=(max(8, 1.9 * n_leaves), 1.55 * (depth_shown + 1) + 0.8))
    ax.set_axis_off()

    for i, (x, yv) in pos.items():
        nd = nodes[i]
        if not nd.is_leaf and nd.depth < max_depth:
            for c in (nd.left, nd.right):
                cx, cy = pos[c]
                on = i in hp and c in hp
                ax.plot([x, cx], [yv - 0.18, cy + 0.2], color=INK if on else NEUTRAL,
                        lw=3 if on else 1.2, zorder=1)
                lab = "tak" if c == nd.left else "nie"
                ax.text((x + cx) / 2, (yv + cy) / 2, lab, fontsize=7.5, color=INK2,
                        ha="center", va="center",
                        bbox=dict(boxstyle="round,pad=0.15", fc=SURFACE, ec="none"))

    for i, (x, yv) in pos.items():
        nd = nodes[i]
        p = nd.proba[1]
        truncated = (not nd.is_leaf) and nd.depth >= max_depth
        if nd.is_leaf:
            txt = f"LIŚĆ  P(zł)={p:.2f}\nn={nd.n}  [{nd.counts[0]} | {nd.counts[1]}]"
        elif truncated:
            txt = f"⋯ poddrzewo\nn={nd.n}  [{nd.counts[0]} | {nd.counts[1]}]"
        else:
            txt = (f"{_short(feature_names[nd.feature])}\n≤ {nd.threshold:.4g}?\n"
                   f"Gini {nd.impurity:.3f}  n={nd.n}\n[{nd.counts[0]} | {nd.counts[1]}]")
        if show_ids:
            txt = f"#{i}  " + txt
        on = i in hp
        ax.text(x, yv, txt, ha="center", va="center", fontsize=8, color=INK, zorder=3,
                bbox=dict(boxstyle="round,pad=0.4", fc=_mix(p),
                          ec=INK if on else "white", lw=2.2 if on else 1))

    ax.set_xlim(-0.8, n_leaves - 0.2)
    ax.set_ylim(-depth_shown - 0.6, 0.6)
    ax.set_title(title or f"Drzewo #{tree.tree_id_} (pokazano do głębokości {max_depth}; "
                 f"[łagodne | złośliwe])", loc="left")
    fig.tight_layout()
    return fig


# ==========================================================================
# Decyzja w węźle: kandydaci i skan progów
# ==========================================================================
def plot_split_candidates(event, ax=None):
    """Spadek Gini dla każdej wylosowanej cechy-kandydatki w węźle."""
    cands = [c for c in event["candidates"] if c["gain"] is not None][::-1]
    fig = None
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 0.45 * len(cands) + 1.2))
    names = [c["name"] for c in cands]
    gains = [c["gain"] for c in cands]
    colors = [MALIGNANT if c["name"] == event["name"] else NEUTRAL for c in cands]
    ax.barh(names, gains, color=colors, height=0.6)
    for k, c in enumerate(cands):
        ax.text(c["gain"], k, f"  {c['gain']:.4f}  (próg {c['threshold']:.4g})",
                va="center", fontsize=8.5, color=INK2)
    ax.set_xlabel("spadek nieczystości Gini po podziale (im więcej, tym lepiej)")
    ax.set_xlim(0, max(gains) * 1.6)
    ax.grid(axis="y", visible=False)
    ax.set_title(f"Węzeł #{event['node_id']}: która wylosowana cecha dzieli najlepiej?")
    if fig:
        fig.tight_layout()
    return fig or ax.figure


def plot_gini_scan(Xn, yn, features, feature_names, chosen=None, parent_gini=None,
                   ncols=3):
    """Ważony Gini dzieci dla KAŻDEGO możliwego progu – po jednym panelu na cechę."""
    from .tree import scan_feature
    k = len(features)
    ncols = min(ncols, k)
    nrows = int(np.ceil(k / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4.2 * ncols, 2.9 * nrows),
                             squeeze=False, sharey=True)
    for a, f in zip(axes.flat, features):
        thr, w = scan_feature(Xn[:, f], yn, 2)
        is_best = f == chosen
        col = MALIGNANT if is_best else INK2
        if len(thr):
            a.plot(thr, w, color=col, lw=1.8)
            i = int(np.argmin(w))
            a.scatter([thr[i]], [w[i]], s=60, color=col, zorder=3, edgecolor=SURFACE, lw=2)
            low = parent_gini is None or w[i] < 0.8 * parent_gini
            a.annotate(f"min {w[i]:.3f}\nprzy {thr[i]:.4g}", (thr[i], w[i]),
                       textcoords="offset points", xytext=(8, 10) if low else (8, -30),
                       fontsize=8, color=INK2)
        if parent_gini is not None:
            a.axhline(parent_gini, color=NEUTRAL, ls="--", lw=1)
        a.set_title(("★ " if is_best else "") + _short(feature_names[f], 30), fontsize=10)
        a.set_xlabel("próg")
    for a in axes[:, 0]:
        a.set_ylabel("ważony Gini dzieci")
    for a in list(axes.flat)[k:]:
        a.set_visible(False)
    fig.suptitle("Skan wszystkich progów (linia przerywana = Gini rodzica; "
                 "★ = zwycięska cecha)", x=0.01, ha="left", fontsize=11, color=INK)
    fig.tight_layout()
    return fig


# ==========================================================================
# Trening lasu
# ==========================================================================
def plot_bootstrap(inbag_counts, tree_id=0):
    """Ile razy każda próbka trafiła do bootstrapu drzewa (0 = OOB)."""
    from math import exp, factorial
    c = inbag_counts[tree_id]
    n = len(c)
    hist = np.bincount(c)
    ks = np.arange(len(hist))
    fig, ax = plt.subplots(figsize=(7, 3.4))
    ax.bar(ks, hist / n, color=[NEUTRAL if k == 0 else BENIGN for k in ks], width=0.7)
    pois = [exp(-1) / factorial(int(k)) for k in ks]
    ax.plot(ks, pois, "o--", color=INK, lw=1.2, ms=6, label="teoria: Poisson(1)")
    ax.text(0, max(hist[0] / n, exp(-1)) + 0.02, f"OOB: {hist[0] / n:.1%}\n(teoria ≈ 36,8%)",
            fontsize=9, color=INK2, va="bottom", ha="center")
    ax.set_ylim(0, max(hist.max() / n, exp(-1)) + 0.1)
    ax.set_xticks(ks)
    ax.set_xlabel("ile razy próbka została wylosowana")
    ax.set_ylabel("odsetek próbek")
    ax.set_title(f"Bootstrap drzewa #{tree_id}: losowanie {n} próbek ze zwracaniem")
    ax.legend()
    fig.tight_layout()
    return fig


def plot_oob_curve(forest, test_acc=None, single_tree_err=None):
    """Błąd OOB (i ew. testowy) w miarę dodawania drzew."""
    curve = np.array(forest.oob_curve_)
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.plot(curve[:, 0], curve[:, 1], color=BENIGN, label="błąd OOB lasu")
    if test_acc is not None:
        ax.plot(np.arange(1, len(test_acc) + 1), 1 - np.asarray(test_acc), color=MALIGNANT,
                label="błąd na zbiorze testowym")
    if single_tree_err is not None:
        ax.axhline(single_tree_err, color=NEUTRAL, ls="--", lw=1.4,
                   label=f"średni błąd pojedynczego drzewa ({single_tree_err:.3f})")
    ax.set_xlabel("liczba drzew w lesie")
    ax.set_ylabel("odsetek błędów")
    ax.set_ylim(bottom=0)
    ax.set_title("Jak błąd maleje wraz z liczbą drzew")
    ax.legend(loc="center right")
    fig.tight_layout()
    return fig


def plot_root_features(forest_counts, stability=None):
    """Cechy w korzeniu: drzewa lasu vs pojedyncze drzewa na bootstrapach."""
    ncols = 2 if stability else 1
    fig, axes = plt.subplots(1, ncols, figsize=(6.5 * ncols, 4), squeeze=False)
    a = axes[0, 0]
    names = list(forest_counts)[::-1]
    a.barh(names, [forest_counts[n] for n in names], color=BENIGN, height=0.6)
    a.set_title("Random Forest: cecha w korzeniu")
    a.set_xlabel("liczba drzew")
    a.grid(axis="y", visible=False)
    if stability:
        c = {}
        for r in stability:
            c[r["root"]] = c.get(r["root"], 0) + 1
        names = sorted(c, key=c.get)
        b = axes[0, 1]
        b.barh(names, [c[n] for n in names], color=NEUTRAL, height=0.6)
        b.set_title("Pojedyncze drzewo (wszystkie cechy)\nna różnych bootstrapach")
        b.set_xlabel("liczba uruchomień")
        b.grid(axis="y", visible=False)
    fig.tight_layout()
    return fig


def plot_disagreement(dis):
    fig, ax = plt.subplots(figsize=(5.2, 4.4))
    im = ax.imshow(dis, cmap=LinearSegmentedColormap.from_list("s", ["#f0efec", VIOLET]))
    ax.set_title("Niezgoda par drzew (odsetek różnych predykcji)")
    ax.set_xlabel("drzewo")
    ax.set_ylabel("drzewo")
    ax.grid(False)
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout()
    return fig


# ==========================================================================
# Ważność cech
# ==========================================================================
def plot_importances(names, mdi, perm, perm_err=None, top_k=15,
                     perm_label="permutacyjna (OOB)"):
    """Dwa panele z tą samą kolejnością cech: MDI oraz ważność permutacyjna."""
    names = np.asarray(names)
    idx = np.argsort(-mdi)[:top_k][::-1]
    fig, axes = plt.subplots(1, 2, figsize=(12, 0.32 * top_k + 1.6), sharey=True)
    axes[0].barh(names[idx], mdi[idx], color=BENIGN, height=0.62)
    axes[0].set_title("MDI – średni spadek Gini (z logów)")
    axes[0].set_xlabel("udział w łącznym spadku Gini")
    axes[1].barh(names[idx], perm[idx], color=MALIGNANT, height=0.62,
                 xerr=None if perm_err is None else perm_err[idx],
                 error_kw=dict(ecolor=INK2, lw=1, capsize=2))
    axes[1].set_title(f"Ważność {perm_label}")
    axes[1].set_xlabel("spadek dokładności po wymieszaniu cechy")
    axes[1].axvline(0, color=INK2, lw=0.8)
    for a in axes:
        a.grid(axis="y", visible=False)
    fig.tight_layout()
    return fig


def plot_correlation(X, names, features):
    """Korelacje Pearsona wybranych cech – źródło „rozmycia” ważności MDI."""
    C = np.corrcoef(X[:, features].T)
    fig, ax = plt.subplots(figsize=(0.55 * len(features) + 3, 0.55 * len(features) + 2))
    im = ax.imshow(C, cmap=DIVERGING, vmin=-1, vmax=1)
    labs = [_short(names[f], 20) for f in features]
    ax.set_xticks(range(len(features)), labs, rotation=60, ha="right")
    ax.set_yticks(range(len(features)), labs)
    for i in range(len(features)):
        for j in range(len(features)):
            ax.text(j, i, f"{C[i, j]:.2f}", ha="center", va="center", fontsize=7,
                    color=INK)
    ax.grid(False)
    ax.set_title("Korelacje najważniejszych cech")
    fig.colorbar(im, ax=ax, shrink=0.7)
    fig.tight_layout()
    return fig


# ==========================================================================
# Wyjaśnienie pojedynczej predykcji
# ==========================================================================
def plot_waterfall(bias, contrib, names, x, top_k=10, title=None):
    """Wodospad Saabasa: od wartości bazowej do P(złośliwy) lasu."""
    names = np.asarray(names)
    order = np.argsort(-np.abs(contrib))
    top, rest = order[:top_k], order[top_k:]
    labels = [f"{_short(names[j], 24)} = {x[j]:.4g}" for j in top]
    vals = list(contrib[top])
    if len(rest):
        labels.append(f"pozostałe cechy ({len(rest)})")
        vals.append(float(contrib[rest].sum()))
    fig, ax = plt.subplots(figsize=(9, 0.42 * (len(vals) + 2) + 1.2))
    cur = bias
    ys = np.arange(len(vals) + 2)[::-1]
    ax.barh(ys[0], bias, color=NEUTRAL, height=0.6)
    ax.text(bias, ys[0], f"  {bias:.3f}", va="center", fontsize=9, color=INK2)
    for k, v in enumerate(vals):
        ax.barh(ys[k + 1], v, left=cur, color=MALIGNANT if v > 0 else BENIGN, height=0.6)
        ax.text(max(cur, cur + v), ys[k + 1], f"  {v:+.3f}", va="center", fontsize=8.5,
                color=INK2)
        cur += v
    ax.barh(ys[-1], cur, color=MALIGNANT if cur >= 0.5 else BENIGN, height=0.6)
    ax.text(cur, ys[-1], f"  {cur:.3f}", va="center", fontsize=9, color=INK,
            fontweight="bold")
    ax.axvline(0.5, color=INK2, ls="--", lw=1)
    ax.set_yticks(ys, ["wartość bazowa"] + labels + ["P(złośliwy) lasu"])
    ax.set_xlim(0, 1.08)
    ax.set_xlabel("P(złośliwy)   (pomarańcz = w stronę złośliwy, niebieski = w stronę łagodny)")
    ax.grid(axis="y", visible=False)
    ax.set_title(title or "Dlaczego taka predykcja? Wkład cech (dekompozycja Saabasa)")
    fig.tight_layout()
    return fig


def plot_tree_votes(per_tree_p, title=None):
    """Rozkład P(złośliwy) zwróconych przez poszczególne drzewa."""
    per_tree_p = np.asarray(per_tree_p)
    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    bins = np.linspace(0, 1, 21)
    ax.hist(per_tree_p[per_tree_p < 0.5], bins=bins, color=BENIGN, rwidth=0.88,
            label=f"głos „łagodny”: {(per_tree_p < 0.5).sum()}")
    ax.hist(per_tree_p[per_tree_p >= 0.5], bins=bins, color=MALIGNANT, rwidth=0.88,
            label=f"głos „złośliwy”: {(per_tree_p >= 0.5).sum()}")
    ax.axvline(per_tree_p.mean(), color=INK, lw=2,
               label=f"średnia = predykcja lasu ({per_tree_p.mean():.3f})")
    ax.axvline(0.5, color=INK2, ls="--", lw=1)
    ax.set_xlabel("P(złośliwy) w liściu danego drzewa")
    ax.set_ylabel("liczba drzew")
    ax.set_title(title or "Jak głosowały drzewa?")
    ax.legend(loc="upper center")
    fig.tight_layout()
    return fig


def plot_margins(margins, title=None):
    margins = np.asarray(margins)
    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    bins = np.linspace(-1, 1, 41)
    ax.hist(margins[margins > 0], bins=bins, color=AQUA, rwidth=0.88,
            label=f"poprawne ({(margins > 0).sum()})")
    ax.hist(margins[margins <= 0], bins=bins, color=MALIGNANT, rwidth=0.88,
            label=f"błędne lub remis ({(margins <= 0).sum()})")
    ax.axvline(0, color=INK2, ls="--", lw=1)
    ax.set_xlabel("margines głosów  (−1 = wszystkie drzewa się mylą, +1 = wszystkie trafiają)")
    ax.set_ylabel("liczba pacjentek")
    ax.set_title(title or "Pewność lasu na zbiorze testowym")
    ax.legend(loc="upper left")
    fig.tight_layout()
    return fig


# ==========================================================================
# Ocena
# ==========================================================================
def plot_confusion(cm, class_names=("łagodny", "złośliwy"), title="Macierz pomyłek"):
    fig, ax = plt.subplots(figsize=(4.2, 3.6))
    ax.imshow(cm, cmap=LinearSegmentedColormap.from_list("b", ["#f0efec", BENIGN]))
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=16,
                    color="white" if cm[i, j] > cm.max() / 2 else INK, fontweight="bold")
    ax.set_xticks(range(len(class_names)), class_names)
    ax.set_yticks(range(len(class_names)), class_names)
    ax.set_xlabel("przewidziana klasa")
    ax.set_ylabel("prawdziwa klasa")
    ax.grid(False)
    ax.set_title(title)
    fig.tight_layout()
    return fig


def plot_roc(curves):
    """curves: {nazwa: (fpr, tpr, auc)}"""
    palette = [BENIGN, MALIGNANT, AQUA, VIOLET]
    fig, ax = plt.subplots(figsize=(5.4, 4.6))
    ax.plot([0, 1], [0, 1], color=NEUTRAL, ls="--", lw=1)
    for (name, (fpr, tpr, auc)), col in zip(curves.items(), palette):
        ax.plot(fpr, tpr, color=col, label=f"{name} (AUC {auc:.3f})")
    ax.set_xlabel("odsetek fałszywych alarmów (1 − swoistość)")
    ax.set_ylabel("czułość (wykryte złośliwe)")
    ax.set_title("Krzywe ROC")
    ax.legend(loc="lower right")
    fig.tight_layout()
    return fig


def plot_threshold(rows):
    """Czułość i precyzja w funkcji progu decyzji."""
    t = [r["threshold"] for r in rows]
    fig, ax = plt.subplots(figsize=(7.5, 3.6))
    ax.plot(t, [r["recall"] for r in rows], color=MALIGNANT, label="czułość (recall)")
    ax.plot(t, [r["precision"] for r in rows], color=BENIGN, label="precyzja")
    ax.plot(t, [r["specificity"] for r in rows], color=AQUA, label="swoistość")
    ax.axvline(0.5, color=INK2, ls="--", lw=1)
    ax.set_xlabel("próg P(złośliwy), od którego mówimy „złośliwy”")
    lo = min(min(r[k] for r in rows) for k in ("recall", "precision", "specificity"))
    ax.set_ylim(max(0, lo - 0.05), 1.02)
    ax.set_title("Wybór progu: kompromis czułość ↔ precyzja")
    ax.legend(loc="lower left")
    fig.tight_layout()
    return fig


def plot_model_comparison(results):
    """results: {nazwa_modelu: {metryka: wartość}} – małe panele per metryka."""
    metrics = ["accuracy", "recall", "precision", "auc"]
    labels = {"accuracy": "dokładność", "recall": "czułość", "precision": "precyzja",
              "auc": "ROC AUC"}
    models = list(results)
    fig, axes = plt.subplots(1, len(metrics), figsize=(3.3 * len(metrics), 0.5 * len(models) + 1.6),
                             sharey=True)
    for a, m in zip(axes, metrics):
        vals = [results[k][m] for k in models]
        a.barh(models[::-1], vals[::-1], color=BENIGN, height=0.6)
        for k, v in enumerate(vals[::-1]):
            a.text(v, k, f" {v:.3f}", va="center", fontsize=8.5, color=INK2)
        a.set_xlim(min(vals) - 0.08, 1.04)
        a.set_title(labels[m])
        a.grid(axis="y", visible=False)
    fig.tight_layout()
    return fig
