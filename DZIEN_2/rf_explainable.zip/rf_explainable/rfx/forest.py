"""Random Forest od podstaw: bootstrap + losowe podzbiory cech + głosowanie.

Do Tracera trafiają zdarzenia:
  forest_start, bootstrap, (node_split, leaf – z drzew), tree_done,
  oob_progress, forest_done, predict.
"""
import numpy as np

from .tree import DecisionTree


class RandomForest:
    def __init__(self, n_estimators=100, max_depth=None, min_samples_split=2,
                 min_samples_leaf=1, max_features="sqrt", bootstrap=True,
                 random_state=None):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.max_features = max_features
        self.bootstrap = bootstrap
        self.random_state = random_state

    def get_params(self):
        return {k: getattr(self, k) for k in (
            "n_estimators", "max_depth", "min_samples_split", "min_samples_leaf",
            "max_features", "bootstrap", "random_state")}

    # ------------------------------------------------------------------
    def fit(self, X, y, feature_names=None, tracer=None, progress=None):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=int)
        n, d = X.shape
        C = int(y.max()) + 1
        rng = np.random.default_rng(self.random_state)

        self.n_classes_ = C
        self.n_features_ = d
        self.feature_names_ = list(feature_names) if feature_names is not None \
            else [f"x{j}" for j in range(d)]
        self.X_train_, self.y_train_ = X, y
        self.trees_ = []
        self.inbag_counts_ = np.zeros((self.n_estimators, n), dtype=np.int16)
        self.oob_curve_ = []                    # (liczba drzew, błąd OOB, pokrycie)
        oob_sum = np.zeros((n, C))
        oob_n = np.zeros(n)

        if tracer:
            tracer.log("forest_start", params=self.get_params(), n_samples=n,
                       n_features=d, class_counts=np.bincount(y, minlength=C),
                       features_per_split=DecisionTree(max_features=self.max_features)
                       ._n_features_to_try(d))

        for t in range(self.n_estimators):
            # 1) BOOTSTRAP: losujemy n próbek ZE ZWRACANIEM
            idx = rng.integers(0, n, n) if self.bootstrap else np.arange(n)
            inbag = np.bincount(idx, minlength=n)
            oob = np.flatnonzero(inbag == 0)        # próbki, których drzewo nie widziało
            self.inbag_counts_[t] = inbag

            if tracer:
                rec = dict(tree_id=t, n_drawn=n, n_unique=int((inbag > 0).sum()),
                           frac_unique=float((inbag > 0).mean()), n_oob=len(oob),
                           max_repeats=int(inbag.max()))
                if tracer.wants_detail(t):
                    rec["oob_indices"] = oob
                    rec["repeat_hist"] = np.bincount(inbag)
                tracer.log("bootstrap", **rec)

            # 2) DRZEWO uczone na próbce bootstrap
            tree = DecisionTree(max_depth=self.max_depth,
                                min_samples_split=self.min_samples_split,
                                min_samples_leaf=self.min_samples_leaf,
                                max_features=self.max_features,
                                random_state=int(rng.integers(2**31 - 1)))
            tree.fit(X[idx], y[idx], n_classes=C, tracer=tracer, tree_id=t,
                     feature_names=self.feature_names_)
            self.trees_.append(tree)

            # 3) OOB: drzewo ocenia próbki, których nie widziało
            tree_oob_acc = None
            if len(oob):
                p = tree.predict_proba(X[oob])
                oob_sum[oob] += p
                oob_n[oob] += 1
                tree_oob_acc = float((p.argmax(1) == y[oob]).mean())
            covered = oob_n > 0
            oob_err = float((oob_sum[covered].argmax(1) != y[covered]).mean()) \
                if covered.any() else float("nan")
            self.oob_curve_.append((t + 1, oob_err, float(covered.mean())))

            if tracer:
                root = tree.nodes_[0]
                tracer.log("tree_done", tree_id=t, n_nodes=len(tree.nodes_),
                           n_leaves=tree.n_leaves_, depth=tree.depth_,
                           root_feature=None if root.is_leaf else self.feature_names_[root.feature],
                           root_threshold=None if root.is_leaf else root.threshold,
                           tree_oob_accuracy=tree_oob_acc)
                tracer.log("oob_progress", n_trees=t + 1, oob_error=oob_err,
                           oob_coverage=float(covered.mean()))
            if progress:
                progress(t + 1, self.n_estimators)

        with np.errstate(invalid="ignore", divide="ignore"):
            self.oob_decision_function_ = oob_sum / oob_n[:, None]
        self.oob_score_ = 1.0 - self.oob_curve_[-1][1]

        imp = np.mean([tr.feature_importances_ for tr in self.trees_], axis=0)
        self.feature_importances_ = imp / imp.sum()

        if tracer:
            tracer.log("forest_done", n_trees=self.n_estimators,
                       oob_score=self.oob_score_,
                       mean_depth=float(np.mean([tr.depth_ for tr in self.trees_])),
                       mean_leaves=float(np.mean([tr.n_leaves_ for tr in self.trees_])))
        return self

    # ------------------------------------------------------------------
    def tree_probas(self, X):
        """Prawdopodobieństwa z KAŻDEGO drzewa osobno: (n_drzew, n_próbek, n_klas)."""
        return np.stack([t.predict_proba(X) for t in self.trees_])

    def predict_proba(self, X):
        """Głosowanie miękkie (jak w sklearn): średnia prawdopodobieństw drzew."""
        return self.tree_probas(X).mean(axis=0)

    def predict(self, X):
        return self.predict_proba(X).argmax(axis=1)

    def hard_votes(self, X):
        """Głosowanie twarde: ile drzew wskazało każdą klasę."""
        preds = self.tree_probas(X).argmax(axis=2)       # (T, n)
        return np.stack([(preds == c).sum(0) for c in range(self.n_classes_)], axis=1)

    def predict_logged(self, x, tracer, sample_id=None, cls=1):
        """Predykcja jednej próbki z zapisem głosów każdego drzewa do logu."""
        x = np.asarray(x, dtype=float)
        tp = self.tree_probas(x[None, :])[:, 0, :]           # (T, C)
        proba = tp.mean(0)
        votes = np.bincount(tp.argmax(1), minlength=self.n_classes_)
        tracer.log("predict", sample_id=sample_id, proba=proba,
                   predicted=int(proba.argmax()), hard_votes=votes,
                   per_tree_p=tp[:, cls],
                   vote_margin=float(abs(votes[1] - votes[0]) / len(self.trees_))
                   if self.n_classes_ == 2 else None)
        return proba
