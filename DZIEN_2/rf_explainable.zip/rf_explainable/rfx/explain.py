"""Narzędzia wyjaśniające: dlaczego las podjął taką decyzję?

Poziomy wyjaśnień:
  • globalny  – ważność cech (MDI z logów oraz permutacyjna na OOB),
  • lokalny   – dekompozycja Saabasa dla jednej próbki
                (P(złośliwy) = wartość bazowa + Σ wkładów cech),
  • zespołowy – margines głosów, różnorodność drzew, stabilność pojedynczego drzewa.
"""
import numpy as np

from .tree import DecisionTree


# ==========================================================================
# 1. Ważność globalna
# ==========================================================================
def mdi_importance(forest):
    """Mean Decrease in Impurity – średni ważony spadek Gini (jak w sklearn)."""
    return forest.feature_importances_


def mdi_from_log(tracer, n_features, n_trees):
    """To samo MDI, ale odtworzone WYŁĄCZNIE z logu zdarzeń node_split.

    Dowód, że log zawiera pełną informację o decyzjach podziału.
    """
    per_tree = np.zeros((n_trees, n_features))
    for e in tracer.filter("node_split"):
        per_tree[e["tree_id"], e["feature"]] += e["weighted_gain"]
    s = per_tree.sum(axis=1, keepdims=True)
    per_tree = np.divide(per_tree, s, out=np.zeros_like(per_tree), where=s > 0)
    imp = per_tree.mean(axis=0)
    return imp / imp.sum()


def permutation_importance_oob(forest, n_repeats=3, random_state=0):
    """Ważność permutacyjna Breimana liczona na próbkach OOB.

    Dla każdego drzewa: dokładność na jego próbkach OOB → mieszamy wartości
    jednej cechy → ponownie liczymy dokładność. Spadek = ważność cechy.
    Każde drzewo ocenia tylko dane, których NIE widziało podczas uczenia.
    """
    rng = np.random.default_rng(random_state)
    X, y = forest.X_train_, forest.y_train_
    d = X.shape[1]
    drops = np.zeros((len(forest.trees_), d))
    for t, tree in enumerate(forest.trees_):
        oob = np.flatnonzero(forest.inbag_counts_[t] == 0)
        if len(oob) < 2:
            continue
        Xo, yo = X[oob], y[oob]
        base = (tree.predict(Xo) == yo).mean()
        for j in range(d):
            acc = 0.0
            for _ in range(n_repeats):
                Xp = Xo.copy()
                Xp[:, j] = rng.permutation(Xp[:, j])
                acc += (tree.predict(Xp) == yo).mean()
            drops[t, j] = base - acc / n_repeats
    return drops.mean(axis=0), drops.std(axis=0) / np.sqrt(len(forest.trees_))


def permutation_importance(forest, X, y, n_repeats=10, random_state=0):
    """Ważność permutacyjna na zbiorze testowym (cały las jako model)."""
    rng = np.random.default_rng(random_state)
    base = (forest.predict(X) == y).mean()
    d = X.shape[1]
    drops = np.zeros((n_repeats, d))
    for r in range(n_repeats):
        for j in range(d):
            Xp = X.copy()
            Xp[:, j] = rng.permutation(Xp[:, j])
            drops[r, j] = base - (forest.predict(Xp) == y).mean()
    return drops.mean(axis=0), drops.std(axis=0)


# ==========================================================================
# 2. Wyjaśnienie lokalne – dekompozycja Saabasa
# ==========================================================================
def tree_contributions(tree, x, cls=1):
    """Dla jednego drzewa: P(cls) w liściu = bias (korzeń) + Σ wkładów cech.

    Każdy krok ścieżki rodzic → dziecko zmienia P(cls); tę zmianę
    przypisujemy cesze, według której rozdzielono rodzica.
    """
    contrib = np.zeros(tree.n_features_)
    path = tree.decision_path(x)
    for parent, child in zip(path[:-1], path[1:]):
        f = tree._feature[parent]
        contrib[f] += tree._value[child][cls] - tree._value[parent][cls]
    return float(tree._value[0][cls]), contrib


def forest_contributions(forest, x, cls=1):
    """Uśredniona dekompozycja po wszystkich drzewach.

    Zwraca (bias, wkłady[cechy], wkłady_per_drzewo[T, cechy], predykcja).
    Tożsamość: bias + wkłady.sum() == forest.predict_proba(x)[cls]  (dokładnie).
    """
    x = np.asarray(x, dtype=float)
    biases, contribs = [], []
    for tree in forest.trees_:
        b, c = tree_contributions(tree, x, cls)
        biases.append(b)
        contribs.append(c)
    contribs = np.array(contribs)
    bias = float(np.mean(biases))
    total = contribs.mean(axis=0)
    return bias, total, contribs, bias + total.sum()


def path_table(forest, x, cls=1, max_trees=None):
    """Czytelne ścieżki decyzji próbki x w każdym drzewie."""
    rows = []
    for t, tree in enumerate(forest.trees_[:max_trees]):
        steps, leaf = tree.explain_path(x, cls)
        txt = " → ".join(
            f"{s['name']} {'≤' if s['go_left'] else '>'} {s['threshold']:.3g}" for s in steps)
        p = float(tree._value[leaf][cls])
        rows.append({"drzewo": t, "głos": int(p >= 0.5), "P(złośliwy)": round(p, 3),
                     "głębokość": len(steps), "ścieżka": txt})
    return rows


# ==========================================================================
# 3. Dynamika zespołu
# ==========================================================================
def vote_margins(forest, X, y):
    """Margines: (odsetek drzew za klasą prawdziwą) − (odsetek za inną klasą).

    1 = wszystkie drzewa zgodne i trafne, −1 = wszystkie zgodne i błędne,
    okolice 0 = las „waha się”.
    """
    votes = forest.hard_votes(X) / len(forest.trees_)
    rows = np.arange(len(y))
    return votes[rows, y] - votes[rows, 1 - y]


def accuracy_vs_n_trees(forest, X, y):
    """Dokładność lasu na teście w miarę dodawania kolejnych drzew."""
    tp = forest.tree_probas(X)                               # (T, n, C)
    cum = np.cumsum(tp, axis=0) / np.arange(1, len(tp) + 1)[:, None, None]
    return (cum.argmax(axis=2) == y[None, :]).mean(axis=1)


def tree_strength_and_correlation(forest, X, y):
    """Breiman: jakość lasu zależy od SIŁY drzew i ich KORELACJI.

    siła   – średnia dokładność pojedynczego drzewa,
    niezgoda – średni odsetek próbek, na których dwa drzewa się różnią.
    """
    preds = forest.tree_probas(X).argmax(axis=2)             # (T, n)
    acc = (preds == y[None, :]).mean(axis=1)
    T = len(preds)
    dis = np.zeros((T, T))
    for i in range(T):
        dis[i] = (preds[i][None, :] != preds).mean(axis=1)
    off = dis[~np.eye(T, dtype=bool)]
    return {"tree_accuracy": acc, "mean_tree_accuracy": float(acc.mean()),
            "disagreement_matrix": dis, "mean_disagreement": float(off.mean())}


def single_tree_stability(X, y, X_test, y_test, feature_names, n_runs=30,
                          max_depth=None, random_state=0):
    """Jak bardzo zmienia się POJEDYNCZE drzewo, gdy lekko zmienią się dane?

    Uczymy klasyczne drzewo (wszystkie cechy w każdym węźle) na kolejnych
    próbkach bootstrap i zapisujemy cechę w korzeniu, cechy z poziomu 1
    i dokładność na teście.
    """
    rng = np.random.default_rng(random_state)
    n = len(y)
    out = []
    for r in range(n_runs):
        idx = rng.integers(0, n, n)
        t = DecisionTree(max_depth=max_depth, max_features=None,
                         random_state=int(rng.integers(2**31 - 1))).fit(X[idx], y[idx])
        root = t.nodes_[0]
        lvl1 = [feature_names[t.nodes_[c].feature] for c in (root.left, root.right)
                if c >= 0 and not t.nodes_[c].is_leaf]
        out.append({"run": r, "root": feature_names[root.feature],
                    "root_threshold": root.threshold, "level1": lvl1,
                    "n_leaves": t.n_leaves_, "depth": t.depth_,
                    "test_accuracy": float((t.predict(X_test) == y_test).mean())})
    return out


def root_feature_counts(forest):
    """Jakie cechy trafiły do korzeni drzew w lesie (efekt losowania cech)."""
    c = {}
    for t in forest.trees_:
        r = t.nodes_[0]
        if not r.is_leaf:
            name = forest.feature_names_[r.feature]
            c[name] = c.get(name, 0) + 1
    return dict(sorted(c.items(), key=lambda kv: -kv[1]))


def node_data(forest, tree_id, node_id):
    """Odtwarza dane, które drzewo „widziało” w danym węźle.

    Próbka bootstrap = wiersze treningowe powtórzone tyle razy, ile razy
    zostały wylosowane (inbag_counts_), potem filtr warunkami ścieżki.
    """
    tree = forest.trees_[tree_id]
    rep = forest.inbag_counts_[tree_id]
    Xb = np.repeat(forest.X_train_, rep, axis=0)
    yb = np.repeat(forest.y_train_, rep)
    m = tree.node_mask(Xb, node_id)
    return Xb[m], yb[m]


# ==========================================================================
# 4. Narracja w języku naturalnym
# ==========================================================================
def explain_node_text(event):
    """Opis zdarzenia node_split zrozumiały dla człowieka."""
    lines = [
        f"Drzewo {event['tree_id']}, węzeł {event['node_id']} (głębokość {event['depth']}): "
        f"{event['n']} próbek, łagodne/złośliwe = {event['counts'][0]}/{event['counts'][1]}, "
        f"Gini = {event['gini']:.3f}."]
    cands = event.get("candidates")
    if cands:
        names = ", ".join(c["name"] for c in cands[:6])
        if len(cands) > 6:
            names += f" i {len(cands) - 6} innych"
        lines.append(f"Sprawdzono {len(cands)} cech-kandydatek (od najlepszej): {names}.")
        valid = [c for c in cands if c["gain"] is not None]
        if len(valid) > 1:
            second = valid[1]
            lines.append(
                f"Wygrała „{event['name']}” z progiem {event['threshold']:.4g}: spadek Gini "
                f"{event['gain']:.4f}. Druga była „{second['name']}” "
                f"({second['gain']:.4f}).")
        else:
            lines.append(f"Wygrała „{event['name']}” z progiem {event['threshold']:.4g}.")
    else:
        lines.append(f"Podział: {event['name']} ≤ {event['threshold']:.4g} "
                     f"(spadek Gini {event['gain']:.4f}).")
    lines.append(f"Na lewo trafia {event['n_left']} próbek, na prawo {event['n_right']}.")
    return " ".join(lines)


def explain_prediction_text(forest, x, feature_names, cls=1, top_k=4):
    """Opis predykcji: głosy drzew + najważniejsze wkłady cech."""
    bias, contrib, _, p = forest_contributions(forest, x, cls)
    votes = forest.hard_votes(np.asarray(x)[None, :])[0]
    T = len(forest.trees_)
    label = "ZŁOŚLIWY" if p >= 0.5 else "ŁAGODNY"
    order = np.argsort(-np.abs(contrib))[:top_k]
    parts = []
    for j in order:
        kier = "podnosi" if contrib[j] > 0 else "obniża"
        parts.append(f"{feature_names[j]} = {x[j]:.4g} {kier} P(złośliwy) o {abs(contrib[j]):.3f}")
    return (
        f"Las: {label}, P(złośliwy) = {p:.3f}. Głosy drzew: {votes[1]} za złośliwym, "
        f"{votes[0]} za łagodnym (z {T}). Punkt wyjścia (odsetek złośliwych w próbkach "
        f"bootstrap) = {bias:.3f}. Najsilniejsze wkłady: " + "; ".join(parts) + ".")
