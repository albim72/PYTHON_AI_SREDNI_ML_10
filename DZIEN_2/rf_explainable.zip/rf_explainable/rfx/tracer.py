"""Tracer: strukturalny dziennik decyzji algorytmu (format JSON Lines).

Każde zdarzenie to słownik z polami `seq` (numer kolejny), `event` (typ)
oraz danymi zdarzenia. Zdarzenia trzymamy w pamięci i opcjonalnie
dopisujemy do pliku .jsonl, aby można je było analizować poza Pythonem.
"""
import json

import numpy as np


def _to_jsonable(obj):
    """Zamienia typy NumPy na zwykłe typy Pythona (JSON nie zna np.float64)."""
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return _to_jsonable(obj.tolist())
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return round(float(obj), 6)
    if isinstance(obj, float):
        return round(obj, 6)
    return obj


class Tracer:
    """Zbiera zdarzenia z treningu i predykcji.

    detail_trees – identyfikatory drzew, dla których zapisujemy PEŁNY ślad
    (wszystkie cechy-kandydatki w każdym węźle). Dla pozostałych drzew
    zapisujemy tylko podsumowania, inaczej log szybko rośnie do dziesiątek MB.
    """

    def __init__(self, path=None, detail_trees=(0, 1, 2), echo=False):
        self.events = []
        self.path = path
        self.detail_trees = set(detail_trees)
        self.echo = echo
        if path:
            open(path, "w", encoding="utf-8").close()  # wyczyść plik

    def wants_detail(self, tree_id):
        return tree_id in self.detail_trees

    def log(self, event, **data):
        rec = _to_jsonable({"seq": len(self.events), "event": event, **data})
        self.events.append(rec)
        if self.path:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        if self.echo:
            print(json.dumps(rec, ensure_ascii=False)[:200])
        return rec

    def filter(self, event=None, **match):
        """Zwraca zdarzenia danego typu, pasujące do podanych pól."""
        out = []
        for e in self.events:
            if event is not None and e["event"] != event:
                continue
            if all(e.get(k) == v for k, v in match.items()):
                out.append(e)
        return out

    def counts(self):
        """Ile zdarzeń każdego typu zapisano."""
        c = {}
        for e in self.events:
            c[e["event"]] = c.get(e["event"], 0) + 1
        return c

    def to_jsonl(self):
        return "\n".join(json.dumps(e, ensure_ascii=False) for e in self.events)
