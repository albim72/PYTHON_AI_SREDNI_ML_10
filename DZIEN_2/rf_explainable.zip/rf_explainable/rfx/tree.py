"""Drzewo decyzyjne CART (kryterium Gini) napisane od podstaw w NumPy.

Każda decyzja podczas budowy drzewa trafia do Tracera:
  • node_split – węzeł został podzielony (jaka cecha, jaki próg, jaki zysk),
                 a dla drzew „szczegółowych” także lista WSZYSTKICH
                 wylosowanych cech-kandydatek z ich najlepszym progiem i zyskiem,
  • leaf       – węzeł został liściem (i dlaczego).
"""
from dataclasses import dataclass

import numpy as np


# --------------------------------------------------------------------------
# Nieczystość Giniego
# --------------------------------------------------------------------------
def gini(counts):
    """Gini = 1 − Σ p_k²  (0 = węzeł czysty, 0.5 = pół na pół przy 2 klasach).

    Działa dla pojedynczego wektora liczności [n_0, n_1, ...] oraz dla
    macierzy, w której każdy wiersz to osobny wektor liczności.
    """
    counts = np.asarray(counts, dtype=float)
    n = counts.sum(axis=-1, keepdims=True)
    p = counts / np.maximum(n, 1)
    return 1.0 - (p ** 2).sum(axis=-1)


# --------------------------------------------------------------------------
# Przegląd wszystkich progów dla jednej cechy
# --------------------------------------------------------------------------
def scan_feature(x, y, n_classes, min_samples_leaf=1):
    """Sprawdza KAŻDY możliwy próg dla cechy x.

    Sortujemy wartości cechy; próg kładziemy w połowie między kolejnymi
    różnymi wartościami. Dzięki sumom skumulowanym liczności klas po lewej
    i prawej stronie dostajemy w jednym przebiegu ważony Gini dzieci
    dla wszystkich progów naraz.

    Zwraca (progi, ważony_gini_dzieci) – tylko dla poprawnych progów.
    """
    order = np.argsort(x, kind="mergesort")
    xs, ys = x[order], y[order]
    n = len(ys)
    if n < 2:
        return np.empty(0), np.empty(0)

    onehot = np.eye(n_classes)[ys]                 # (n, C)
    left = np.cumsum(onehot, axis=0)[:-1]          # liczności klas po lewej
    right = onehot.sum(axis=0) - left              # ... i po prawej
    n_left = np.arange(1, n)
    n_right = n - n_left

    weighted = (n_left * gini(left) + n_right * gini(right)) / n
    thresholds = (xs[1:] + xs[:-1]) / 2.0

    valid = (
        (xs[1:] > xs[:-1])                         # próg między RÓŻNYMI wartościami
        & (n_left >= min_samples_leaf)
        & (n_right >= min_samples_leaf)
    )
    return thresholds[valid], weighted[valid]


def best_split_for_feature(x, y, n_classes, min_samples_leaf=1):
    """Najlepszy próg dla jednej cechy: (próg, ważony Gini dzieci) albo None."""
    thr, w = scan_feature(x, y, n_classes, min_samples_leaf)
    if len(thr) == 0:
        return None
    i = int(np.argmin(w))
    return float(thr[i]), float(w[i])


# --------------------------------------------------------------------------
# Węzeł drzewa
# --------------------------------------------------------------------------
@dataclass
class Node:
    id: int
    depth: int
    n: int                       # liczba próbek (z powtórzeniami bootstrapu)
    counts: np.ndarray           # liczności klas w węźle
    impurity: float              # Gini węzła
    feature: int = -1            # -1 oznacza liść
    threshold: float = float("nan")
    left: int = -1
    right: int = -1
    gain: float = 0.0            # spadek Gini osiągnięty przez podział
    leaf_reason: str = ""

    @property
    def is_leaf(self):
        return self.feature < 0

    @property
    def proba(self):
        return self.counts / self.counts.sum()


# --------------------------------------------------------------------------
# Drzewo decyzyjne
# --------------------------------------------------------------------------
class DecisionTree:
    """Klasyfikator CART z losowaniem podzbioru cech w każdym węźle.

    max_features: None (wszystkie cechy – klasyczne drzewo), "sqrt", "log2",
                  liczba całkowita albo ułamek (0–1).
    """

    def __init__(self, max_depth=None, min_samples_split=2, min_samples_leaf=1,
                 max_features=None, random_state=None):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.max_features = max_features
        self.random_state = random_state

    # -- ile cech losujemy w każdym węźle ---------------------------------
    def _n_features_to_try(self, d):
        mf = self.max_features
        if mf is None:
            return d
        if mf == "sqrt":
            return max(1, int(np.sqrt(d)))
        if mf == "log2":
            return max(1, int(np.log2(d)))
        if isinstance(mf, float):
            return max(1, int(mf * d))
        return max(1, min(d, int(mf)))

    # -- trening -----------------------------------------------------------
    def fit(self, X, y, n_classes=None, tracer=None, tree_id=0, feature_names=None):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=int)
        self.rng_ = np.random.default_rng(self.random_state)
        self.n_classes_ = n_classes or int(y.max()) + 1
        self.n_features_ = X.shape[1]
        self.feature_names_ = list(feature_names) if feature_names is not None \
            else [f"x{j}" for j in range(self.n_features_)]
        self.tree_id_ = tree_id
        self.nodes_ = []
        self._n_root = len(y)
        self._tracer = tracer
        self._detail = tracer is not None and tracer.wants_detail(tree_id)

        self._grow(X, y, depth=0)

        self._tracer = None                      # nie trzymamy referencji
        self._compile()
        self._compute_importances()
        return self

    def _grow(self, X, y, depth):
        counts = np.bincount(y, minlength=self.n_classes_)
        node = Node(id=len(self.nodes_), depth=depth, n=len(y),
                    counts=counts, impurity=float(gini(counts)))
        self.nodes_.append(node)

        # 1) Czy w ogóle próbujemy dzielić?
        reason = None
        if self.max_depth is not None and depth >= self.max_depth:
            reason = "osiągnięto max_depth"
        elif node.impurity == 0.0:
            reason = "węzeł czysty (jedna klasa)"
        elif node.n < self.min_samples_split:
            reason = "za mało próbek (min_samples_split)"

        candidates, best = [], None
        if reason is None:
            # 2) Losujemy podzbiór cech – serce „random” w Random Forest
            k = self._n_features_to_try(self.n_features_)
            feats = self.rng_.choice(self.n_features_, size=k, replace=False)

            # 3) Dla każdej wylosowanej cechy szukamy najlepszego progu
            for f in feats:
                res = best_split_for_feature(X[:, f], y, self.n_classes_,
                                             self.min_samples_leaf)
                cand = {"feature": int(f), "name": self.feature_names_[f]}
                if res is None:
                    cand.update(threshold=None, child_gini=None, gain=None)
                else:
                    thr, w = res
                    cand.update(threshold=thr, child_gini=w, gain=node.impurity - w)
                candidates.append(cand)

            # 4) Wygrywa cecha z największym spadkiem Gini
            valid = [c for c in candidates if c["gain"] is not None and c["gain"] > 1e-12]
            if valid:
                best = max(valid, key=lambda c: c["gain"])
            else:
                reason = "żadna wylosowana cecha nie poprawia Gini"

        # --- liść -----------------------------------------------------------
        if best is None:
            node.leaf_reason = reason
            if self._tracer is not None:
                self._tracer.log(
                    "leaf", tree_id=self.tree_id_, node_id=node.id, depth=depth,
                    n=node.n, counts=counts, gini=node.impurity,
                    proba=node.proba, reason=reason)
            return node.id

        # --- podział --------------------------------------------------------
        f, thr = best["feature"], best["threshold"]
        mask = X[:, f] <= thr
        node.feature, node.threshold, node.gain = f, thr, best["gain"]

        if self._tracer is not None:
            rec = dict(
                tree_id=self.tree_id_, node_id=node.id, depth=depth, n=node.n,
                counts=counts, gini=node.impurity,
                feature=f, name=best["name"], threshold=thr, gain=best["gain"],
                weighted_gain=node.n / self._n_root * best["gain"],
                n_left=int(mask.sum()), n_right=int((~mask).sum()),
                n_candidates=len(candidates))
            if self._detail:
                rec["candidates"] = sorted(
                    candidates, key=lambda c: -1 if c["gain"] is None else -c["gain"])
            self._tracer.log("node_split", **rec)

        node.left = self._grow(X[mask], y[mask], depth + 1)
        node.right = self._grow(X[~mask], y[~mask], depth + 1)
        return node.id

    # -- struktury tablicowe do szybkiej predykcji ------------------------
    def _compile(self):
        self._feature = np.array([nd.feature for nd in self.nodes_])
        self._threshold = np.array([nd.threshold for nd in self.nodes_])
        self._left = np.array([nd.left for nd in self.nodes_])
        self._right = np.array([nd.right for nd in self.nodes_])
        self._value = np.array([nd.proba for nd in self.nodes_])
        self._parent = np.full(len(self.nodes_), -1)
        for nd in self.nodes_:
            if not nd.is_leaf:
                self._parent[nd.left] = self._parent[nd.right] = nd.id
        self.depth_ = max(nd.depth for nd in self.nodes_)
        self.n_leaves_ = int((self._feature < 0).sum())

    def _compute_importances(self):
        """MDI: suma ważonych spadków Gini, w których brała udział cecha."""
        imp = np.zeros(self.n_features_)
        for nd in self.nodes_:
            if not nd.is_leaf:
                imp[nd.feature] += nd.n * nd.gain
        imp /= self._n_root
        s = imp.sum()
        self.feature_importances_ = imp / s if s > 0 else imp

    # -- predykcja ---------------------------------------------------------
    def apply(self, X):
        """Indeks liścia, do którego trafia każda próbka."""
        X = np.asarray(X, dtype=float)
        ids = np.zeros(len(X), dtype=int)
        rows = np.arange(len(X))
        while True:
            feat = self._feature[ids]
            leaf = feat < 0
            if leaf.all():
                return ids
            go_left = X[rows, np.where(leaf, 0, feat)] <= self._threshold[ids]
            nxt = np.where(go_left, self._left[ids], self._right[ids])
            ids = np.where(leaf, ids, nxt)

    def predict_proba(self, X):
        return self._value[self.apply(X)]

    def predict(self, X):
        return self.predict_proba(X).argmax(axis=1)

    def decision_path(self, x):
        """Lista węzłów (od korzenia do liścia) odwiedzonych przez próbkę x."""
        path, i = [0], 0
        while self._feature[i] >= 0:
            i = self._left[i] if x[self._feature[i]] <= self._threshold[i] else self._right[i]
            path.append(int(i))
        return path

    def node_mask(self, X, node_id):
        """Które wiersze X docierają do węzła node_id (odtwarzamy warunki ścieżki)."""
        chain = []
        i = node_id
        while self._parent[i] >= 0:
            chain.append(i)
            i = self._parent[i]
        mask = np.ones(len(X), dtype=bool)
        for child in reversed(chain):
            par = self._parent[child]
            le = X[:, self._feature[par]] <= self._threshold[par]
            mask &= le if child == self._left[par] else ~le
        return mask

    def explain_path(self, x, cls=1):
        """Ścieżka próbki x z opisem każdego kroku i zmianą P(klasa=cls)."""
        steps = []
        path = self.decision_path(x)
        for parent, child in zip(path[:-1], path[1:]):
            f = int(self._feature[parent])
            steps.append({
                "node_id": parent, "feature": f, "name": self.feature_names_[f],
                "value": float(x[f]), "threshold": float(self._threshold[parent]),
                "go_left": bool(x[f] <= self._threshold[parent]),
                "p_before": float(self._value[parent][cls]),
                "p_after": float(self._value[child][cls]),
            })
        return steps, int(path[-1])
