"""Metryki napisane od podstaw (klasa pozytywna = 1 = nowotwór złośliwy)."""
import numpy as np


def confusion_matrix(y_true, y_pred, n_classes=2):
    """Wiersze = klasa prawdziwa, kolumny = klasa przewidziana."""
    cm = np.zeros((n_classes, n_classes), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[t, p] += 1
    return cm


def accuracy(y_true, y_pred):
    return float(np.mean(np.asarray(y_true) == np.asarray(y_pred)))


def binary_report(y_true, y_pred, pos=1):
    """Czułość (recall), precyzja, swoistość, F1 – dla klasy pozytywnej."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    tp = int(((y_pred == pos) & (y_true == pos)).sum())
    fp = int(((y_pred == pos) & (y_true != pos)).sum())
    fn = int(((y_pred != pos) & (y_true == pos)).sum())
    tn = int(((y_pred != pos) & (y_true != pos)).sum())
    recall = tp / (tp + fn) if tp + fn else 0.0
    precision = tp / (tp + fp) if tp + fp else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"accuracy": (tp + tn) / len(y_true), "recall": recall,
            "precision": precision, "specificity": specificity, "f1": f1,
            "TP": tp, "FP": fp, "FN": fn, "TN": tn}


def roc_curve(y_true, score):
    """Krzywa ROC: przesuwamy próg od najwyższego wyniku w dół."""
    y_true = np.asarray(y_true)
    order = np.argsort(-np.asarray(score), kind="mergesort")
    s, y = np.asarray(score)[order], y_true[order]
    distinct = np.r_[np.flatnonzero(np.diff(s)), len(s) - 1]   # ostatni indeks każdej wartości
    tps = np.cumsum(y)[distinct]
    fps = (distinct + 1) - tps
    tpr = np.r_[0, tps / max(y.sum(), 1)]
    fpr = np.r_[0, fps / max((1 - y).sum(), 1)]
    thr = np.r_[np.inf, s[distinct]]
    return fpr, tpr, thr


def roc_auc(y_true, score):
    """Pole pod krzywą ROC (metoda trapezów)."""
    fpr, tpr, _ = roc_curve(y_true, score)
    return float(np.sum(np.diff(fpr) * (tpr[1:] + tpr[:-1]) / 2))


def log_loss(y_true, proba_pos, eps=1e-12):
    p = np.clip(np.asarray(proba_pos), eps, 1 - eps)
    y = np.asarray(y_true)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def threshold_table(y_true, score, thresholds):
    """Jak zmienia się czułość/precyzja przy różnych progach decyzji."""
    rows = []
    for t in thresholds:
        r = binary_report(y_true, (np.asarray(score) >= t).astype(int))
        rows.append({"threshold": float(t), **r})
    return rows
