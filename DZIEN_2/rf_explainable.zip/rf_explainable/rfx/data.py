"""Wczytanie zbioru Breast Cancer Wisconsin (Diagnostic) i podział train/test."""
import numpy as np
from sklearn.datasets import load_breast_cancer

CLASS_NAMES = ["łagodny", "złośliwy"]


def load_data(test_size=0.25, random_state=42):
    """Zwraca słownik z danymi.

    UWAGA na kodowanie: w sklearn target 0 = malignant, 1 = benign.
    Odwracamy je, żeby klasa POZYTYWNA (1) oznaczała nowotwór ZŁOŚLIWY –
    wtedy „czułość” to odsetek wykrytych przypadków złośliwych.
    """
    ds = load_breast_cancer()
    X = ds.data.astype(float)
    y = 1 - ds.target                               # 1 = złośliwy, 0 = łagodny
    names = [str(n) for n in ds.feature_names]

    # Podział warstwowy (stratified) napisany ręcznie – proporcje klas zachowane
    rng = np.random.default_rng(random_state)
    test_idx = []
    for c in np.unique(y):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        test_idx.extend(idx[: int(round(test_size * len(idx)))])
    test_mask = np.zeros(len(y), dtype=bool)
    test_mask[test_idx] = True

    return {
        "X_train": X[~test_mask], "y_train": y[~test_mask],
        "X_test": X[test_mask], "y_test": y[test_mask],
        "idx_train": np.flatnonzero(~test_mask), "idx_test": np.flatnonzero(test_mask),
        "feature_names": names, "class_names": CLASS_NAMES,
        "X": X, "y": y,
    }
