"""Buduje notebook RandomForest_krok_po_kroku.ipynb z kodu pakietu rfx.

Kod algorytmu w notebooku jest KOPIĄ funkcji/klas z rfx/*.py (wyciągniętą
przez moduł ast), więc notebook i aplikacja www zawsze mają tę samą logikę.
Uruchomienie:  python tools/build_notebook.py [--execute]
"""
import ast
import re
import sys
from pathlib import Path

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "rfx"
OUT = ROOT / "RandomForest_krok_po_kroku.ipynb"


def src(module, *names):
    """Źródło wskazanych definicji najwyższego poziomu z modułu rfx/<module>.py."""
    text = (PKG / f"{module}.py").read_text(encoding="utf-8")
    tree = ast.parse(text)
    lines = text.splitlines()
    chunks = []
    for name in names:
        for node in tree.body:
            n = getattr(node, "name", None)
            if n is None and isinstance(node, ast.Assign):
                n = node.targets[0].id if isinstance(node.targets[0], ast.Name) else None
            if n == name:
                start = node.lineno - 1
                if getattr(node, "decorator_list", None):
                    start = node.decorator_list[0].lineno - 1
                chunks.append("\n".join(lines[start:node.end_lineno]))
                break
        else:
            raise KeyError(f"{module}.{name}")
    return "\n\n\n".join(chunks)


def module_body(module):
    """Cały moduł bez docstringu i importów (do zwiniętej komórki z wykresami)."""
    text = (PKG / f"{module}.py").read_text(encoding="utf-8")
    tree = ast.parse(text)
    lines = text.splitlines()
    first = next(n for n in tree.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)))
    body = "\n".join(lines[first.lineno - 1:])
    return re.sub(r"^\s*from \.\w+ import .*\n", "", body, flags=re.M)


cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip("\n")))


def code(s, hidden=False):
    c = nbf.v4.new_code_cell(s.strip("\n"))
    if hidden:
        c.metadata["jupyter"] = {"source_hidden": True}
        c.metadata["collapsed"] = True
    cells.append(c)


# ===========================================================================
md(r"""
# Random Forest bez czarnej skrzynki
### Breast Cancer Wisconsin (Diagnostic) — algorytm od podstaw, z dziennikiem decyzji i wizualizacjami

W tym notebooku **budujemy Random Forest od zera w NumPy** i na każdym kroku zapisujemy, *co* algorytm zrobił i *dlaczego*:

| krok | co logujemy | co wizualizujemy |
|---|---|---|
| bootstrap | które próbki wylosowano, które są OOB | rozkład powtórzeń vs Poisson(1) |
| węzeł drzewa | wylosowane cechy, najlepszy próg każdej, spadek Gini | ranking kandydatów, skan progów |
| liść | dlaczego przestaliśmy dzielić | drzewo z kolorem P(złośliwy) |
| las | błąd OOB po każdym drzewie | krzywa uczenia, niezgoda drzew |
| predykcja | głos każdego drzewa, margines | histogram głosów, wodospad wkładów cech |

Biblioteka **scikit-learn służy wyłącznie do wczytania danych i jako punkt odniesienia** (sprawdzamy, że nasza implementacja daje te same wyniki).

**Plan:** 1) dane → 2) dziennik zdarzeń → 3) Gini i wybór progu → 4) drzewo → 5) niestabilność drzewa → 6) las → 7) dynamika zespołu → 8) ocena → 9) ważność globalna → 10) wyjaśnienie pojedynczej predykcji → 11) dlaczego (i kiedy) Random Forest → ćwiczenia.
""")

code(r"""
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from dataclasses import dataclass
from math import exp, factorial
from matplotlib.colors import LinearSegmentedColormap, to_rgb
from sklearn.datasets import load_breast_cancer

pd.set_option("display.max_colwidth", 140)
pd.set_option("display.width", 200)
%matplotlib inline
""")

md("""
<details><summary><b>Kod wykresów</b> (nie jest częścią algorytmu, komórka poniżej jest zwinięta)</summary>

Stałe kolory: <span style="color:#2a78d6">■ niebieski = łagodny</span>, <span style="color:#eb6834">■ pomarańczowy = złośliwy</span>, ■ szary = kontekst.
</details>
""")
code(module_body("viz"), hidden=True)

# ---------------------------------------------------------------------------
md(r"""
## 1. Dane

569 biopsji cienkoigłowych; dla każdego jądra komórkowego zmierzono 10 cech (promień, tekstura, obwód, pole, gładkość, zwartość, wklęsłość, punkty wklęsłe, symetria, wymiar fraktalny). Dla każdej cechy mamy **średnią (`mean`)**, **błąd standardowy (`error`)** i **najgorszą wartość (`worst`)** → 30 cech.

> ⚠️ **Pułapka kodowania:** w scikit-learn `target = 0` oznacza *malignant*. Odwracamy etykiety, aby **klasa pozytywna 1 = złośliwy** — wtedy *czułość* (recall) mówi wprost, jaki odsetek nowotworów złośliwych wykryliśmy.
""")
code(src("data", "CLASS_NAMES", "load_data") + r"""


D = load_data(test_size=0.25, random_state=42)
X_train, y_train, X_test, y_test = D["X_train"], D["y_train"], D["X_test"], D["y_test"]
names = D["feature_names"]
print(f"trening: {X_train.shape}, test: {X_test.shape}")
print(f"odsetek złośliwych – trening: {y_train.mean():.3f}, test: {y_test.mean():.3f}")
pd.DataFrame(X_train[:5], columns=names).iloc[:, :10]
""")

# ---------------------------------------------------------------------------
md(r"""
## 2. Dziennik decyzji (Tracer)

Każde zdarzenie to jeden wiersz JSON (format **JSON Lines**) — łatwo go przefiltrować w pandas, wczytać do Elasticsearch czy przejrzeć w edytorze. Dla kilku wybranych drzew zapisujemy **pełny ślad** (wszystkie cechy-kandydatki w każdym węźle), dla reszty tylko podsumowania.
""")
code(src("tracer", "_to_jsonable", "Tracer"))

# ---------------------------------------------------------------------------
md(r"""
## 3. Nieczystość Giniego i wybór progu

Węzeł z rozkładem klas $p_k$ ma nieczystość
$$G = 1 - \sum_k p_k^2 \qquad (0 = \text{jedna klasa},\; 0{,}5 = \text{pół na pół}).$$

Podział cechą $f$ na progu $\theta$ ocenia się **ważonym Gini dzieci**:
$$G_{\text{dzieci}} = \tfrac{n_L}{n} G_L + \tfrac{n_R}{n} G_R, \qquad \text{zysk} = G_{\text{rodzic}} - G_{\text{dzieci}}.$$

`scan_feature` liczy to **dla wszystkich progów naraz**: sortuje wartości i używa sum skumulowanych liczności klas.
""")
code(src("tree", "gini", "scan_feature", "best_split_for_feature") + r"""


print("Gini całego zbioru treningowego:", round(float(gini(np.bincount(y_train))), 4))
for f in ["worst radius", "mean texture", "worst concave points"]:
    j = names.index(f)
    thr, w = best_split_for_feature(X_train[:, j], y_train, 2)
    print(f"{f:22s} najlepszy próg {thr:8.4f}  →  ważony Gini dzieci {w:.4f}")
""")
code(r"""
# Jak wygląda „poszukiwanie progu”? Pełny skan dla kilku cech na całym zbiorze treningowym
feats = [names.index(f) for f in ["worst radius", "worst concave points", "mean texture"]]
plot_gini_scan(X_train, y_train, feats, names, chosen=feats[0],
               parent_gini=float(gini(np.bincount(y_train))));
""")

# ---------------------------------------------------------------------------
md(r"""
## 4. Drzewo decyzyjne CART

Algorytm rekurencyjny dla każdego węzła:
1. **Warunek stopu?** (max głębokość, węzeł czysty, za mało próbek) → liść.
2. **Losuj** `max_features` cech (w zwykłym drzewie: wszystkie).
3. Dla każdej wylosowanej cechy znajdź **najlepszy próg**.
4. Wybierz cechę z **największym spadkiem Gini**, podziel dane, powtórz dla dzieci.

Każdy krok trafia do dziennika (`node_split`, `leaf`).
""")
code(src("tree", "Node", "DecisionTree"))

md(r"""
### 4.1 Pojedyncze drzewo z pełnym śladem i porównanie ze scikit-learn
Jeśli implementacja jest poprawna, klasyczne drzewo (wszystkie cechy w każdym węźle) powinno mieć **tę samą strukturę** co `DecisionTreeClassifier`: liczbę węzłów, głębokość, cechę w korzeniu i ważności cech. Pojedyncze różnice predykcji wynikają z remisów: przy równych zyskach Gini sklearn losuje kolejność cech, a my bierzemy pierwszą.
""")
code(r"""
from sklearn.tree import DecisionTreeClassifier

tr_tree = Tracer(detail_trees=[0])
tree = DecisionTree(max_features=None).fit(X_train, y_train, tracer=tr_tree, feature_names=names)
sk_tree = DecisionTreeClassifier(random_state=0).fit(X_train, y_train)

print("liczba węzłów   nasze / sklearn:", len(tree.nodes_), "/", sk_tree.tree_.node_count)
print("głębokość       nasze / sklearn:", tree.depth_, "/", sk_tree.get_depth())
print("cecha w korzeniu nasze / sklearn:", names[tree.nodes_[0].feature], "/", names[sk_tree.tree_.feature[0]])
print("zgodność predykcji na teście:   ", (tree.predict(X_test) == sk_tree.predict(X_test)).mean())
print("korelacja ważności cech:        ", np.corrcoef(tree.feature_importances_, sk_tree.feature_importances_)[0, 1].round(5))
print("\nzdarzenia w dzienniku:", tr_tree.counts())
""")
md("**Dziennik pierwszej decyzji (korzeń)** — w surowej postaci JSON i jako zdanie:")
code(r"""
root_event = tr_tree.filter("node_split", node_id=0)[0]
print(json.dumps({k: v for k, v in root_event.items() if k != "candidates"}, ensure_ascii=False, indent=1))
print("\nkandydaci (5 najlepszych z 30):")
pd.DataFrame(root_event["candidates"])[["name", "threshold", "child_gini", "gain"]].head()
""")
code(src("explain", "explain_node_text") + r"""


print(explain_node_text(root_event))
""")
code(r"""
plot_tree(tree, names, max_depth=3, title="Klasyczne drzewo (wszystkie cechy w każdym węźle) – 3 pierwsze poziomy");
""")
code(r"""
# Dlaczego węzły przestały się dzielić?
pd.Series([e["reason"] for e in tr_tree.filter("leaf")]).value_counts()
""")

# ---------------------------------------------------------------------------
md(r"""
## 5. Problem: pojedyncze drzewo jest niestabilne

Uczymy to samo drzewo na **lekko zmienionych danych** (kolejne próbki bootstrap) i patrzymy, co trafia do korzenia i jak zmienia się dokładność. Duża wariancja = model, któremu trudno ufać. To jest główna motywacja dla lasu.
""")
code(src("explain", "single_tree_stability") + r"""


stab = single_tree_stability(X_train, y_train, X_test, y_test, names, n_runs=30)
stab_df = pd.DataFrame(stab)
print("cecha w korzeniu:", stab_df["root"].value_counts().to_dict())
print(f"dokładność pojedynczego drzewa na teście: średnio {stab_df.test_accuracy.mean():.3f}, "
      f"min {stab_df.test_accuracy.min():.3f}, max {stab_df.test_accuracy.max():.3f}, "
      f"odch. std {stab_df.test_accuracy.std():.3f}")
stab_df.head(8)
""")

# ---------------------------------------------------------------------------
md(r"""
## 6. Random Forest

Dwa źródła losowości, które **dekorelują** drzewa:
1. **Bootstrap** — każde drzewo uczy się na $n$ próbkach losowanych ze zwracaniem. Ok. $e^{-1} \approx 36{,}8\%$ próbek nie trafia do próbki → to zbiór **OOB** (*out-of-bag*), darmowy zbiór walidacyjny dla tego drzewa.
2. **Losowy podzbiór cech w każdym węźle** — domyślnie $\lfloor\sqrt{30}\rfloor = 5$ cech. Silna cecha nie może zdominować wszystkich drzew.

Predykcja: **średnia prawdopodobieństw** drzew (głosowanie miękkie, jak w scikit-learn); dodatkowo liczymy głosy twarde.
""")
code(src("forest", "RandomForest"))
code(r"""
tracer = Tracer(path="rf_trace.jsonl", detail_trees=[0, 1, 2])
rf = RandomForest(n_estimators=100, max_features="sqrt", random_state=0)
rf.fit(X_train, y_train, feature_names=names, tracer=tracer)

print("zdarzenia w dzienniku:", tracer.counts())
print(f"dokładność OOB: {rf.oob_score_:.4f}")
print("dziennik zapisany do rf_trace.jsonl")
""")
md("### 6.1 Bootstrap pod lupą")
code(r"""
display(pd.DataFrame(tracer.filter("bootstrap"))[["tree_id", "n_unique", "frac_unique", "n_oob", "max_repeats"]].head())
plot_bootstrap(rf.inbag_counts_, tree_id=0);
""")
md(r"""
### 6.2 Ta sama decyzja w korzeniu — trzy różne drzewa
Każde drzewo widzi inną próbkę i **inne wylosowane cechy**. Porównaj kandydatów w korzeniach drzew 0, 1 i 2.
""")
code(r"""
for t in [0, 1, 2]:
    ev = tracer.filter("node_split", tree_id=t, node_id=0)[0]
    print(explain_node_text(ev), "\n")
    plot_split_candidates(ev); plt.show()
""")
code(src("explain", "node_data") + r"""


# Pełny skan progów dla wszystkich kandydatów w korzeniu drzewa 1 – na danych, które to drzewo naprawdę widziało
ev = tracer.filter("node_split", tree_id=1, node_id=0)[0]
Xn, yn = node_data(rf, 1, 0)
plot_gini_scan(Xn, yn, [c["feature"] for c in ev["candidates"]], names,
               chosen=ev["feature"], parent_gini=ev["gini"]);
""")
code(r"""
plot_tree(rf.trees_[1], names, max_depth=3);
""")
md("### 6.3 Podsumowanie każdego drzewa z dziennika")
code(r"""
trees_df = pd.DataFrame(tracer.filter("tree_done"))[
    ["tree_id", "n_nodes", "n_leaves", "depth", "root_feature", "root_threshold", "tree_oob_accuracy"]]
display(trees_df.head(10))
trees_df[["n_leaves", "depth", "tree_oob_accuracy"]].describe().T
""")

# ---------------------------------------------------------------------------
md(r"""
## 7. Dynamika zespołu: dlaczego wiele słabszych drzew > jedno drzewo

Breiman: błąd lasu zależy od **siły** pojedynczych drzew i od **korelacji** między nimi. Drzewa w lesie są pojedynczo *słabsze* niż klasyczne drzewo (widzą mniej cech), ale **mylą się w różnych miejscach** — uśrednianie znosi ich błędy.
""")
code(src("explain", "accuracy_vs_n_trees", "tree_strength_and_correlation", "root_feature_counts") + r"""


acc_curve = accuracy_vs_n_trees(rf, X_test, y_test)
sc = tree_strength_and_correlation(rf, X_test, y_test)
print(f"średnia dokładność pojedynczego drzewa z lasu: {sc['mean_tree_accuracy']:.3f}")
print(f"dokładność całego lasu:                       {acc_curve[-1]:.3f}")
print(f"średnia niezgoda dwóch drzew:                 {sc['mean_disagreement']:.3f}")
plot_oob_curve(rf, acc_curve, single_tree_err=1 - sc["mean_tree_accuracy"]);
""")
code(r"""
plot_root_features(root_feature_counts(rf), stab);
plot_disagreement(sc["disagreement_matrix"][:40, :40]);
""")

# ---------------------------------------------------------------------------
md(r"""
## 8. Ocena — własne metryki i uczciwe porównanie

W diagnostyce nowotworów błędy nie są symetryczne: **przeoczony nowotwór złośliwy (FN)** jest zwykle dużo groźniejszy niż fałszywy alarm (FP). Dlatego patrzymy przede wszystkim na **czułość**, a próg decyzji traktujemy jako parametr do świadomego wyboru.
""")
code(src("metrics", "confusion_matrix", "accuracy", "binary_report", "roc_curve", "roc_auc",
         "log_loss", "threshold_table"))
code(r"""
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

models = {
    "RF – nasz (od podstaw)": rf.predict_proba(X_test)[:, 1],
    "RF – scikit-learn": RandomForestClassifier(100, random_state=0).fit(X_train, y_train).predict_proba(X_test)[:, 1],
    "Pojedyncze drzewo": tree.predict_proba(X_test)[:, 1],
    "Regresja logistyczna": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
                              .fit(X_train, y_train).predict_proba(X_test)[:, 1],
}
results, curves = {}, {}
for name, p in models.items():
    r = binary_report(y_test, (p >= 0.5).astype(int))
    r["auc"] = roc_auc(y_test, p)
    results[name] = r
    f, t, _ = roc_curve(y_test, p)
    curves[name] = (f, t, r["auc"])
pd.DataFrame(results).T[["accuracy", "recall", "precision", "specificity", "f1", "auc", "FN", "FP"]].round(3)
""")
code(r"""
plot_model_comparison(results);
p_rf = models["RF – nasz (od podstaw)"]
plot_confusion(confusion_matrix(y_test, (p_rf >= 0.5).astype(int)), title="RF (nasz), próg 0,5");
plot_roc(curves);
""")
code(r"""
rows = threshold_table(y_test, p_rf, np.linspace(0.05, 0.95, 37))
plot_threshold(rows);
pd.DataFrame(rows)[["threshold", "recall", "precision", "specificity", "FN", "FP"]].iloc[::4].round(3)
""")
code(src("explain", "vote_margins") + r"""


margins = vote_margins(rf, X_test, y_test)
plot_margins(margins);
wrong = np.flatnonzero((p_rf >= 0.5).astype(int) != y_test)
pd.DataFrame({"indeks testowy": wrong, "prawdziwa": [D["class_names"][c] for c in y_test[wrong]],
              "P(złośliwy)": p_rf[wrong].round(3), "margines": margins[wrong].round(2)})
""")

# ---------------------------------------------------------------------------
md(r"""
## 9. Ważność globalna: które cechy decydują?

* **MDI** (*Mean Decrease in Impurity*) — suma ważonych spadków Gini przypisanych cesze. Liczymy ją **wyłącznie z dziennika** `node_split`, żeby pokazać, że log zawiera pełną informację.
* **Ważność permutacyjna OOB** (oryginalna metoda Breimana) — każde drzewo na swoich próbkach OOB: o ile spada dokładność, gdy wymieszamy wartości jednej cechy?

> **Pułapka korelacji:** `radius`, `perimeter` i `area` są niemal liniowo zależne (r ≈ 0,99). MDI rozdziela zasługę między nie dość przypadkowo, a permutacja jednej z nich niewiele szkodzi, bo pozostałe niosą tę samą informację. Ważność ≠ przyczynowość.
""")
code(src("explain", "mdi_from_log", "permutation_importance_oob") + r"""


mdi_log = mdi_from_log(tracer, len(names), rf.n_estimators)
print("max różnica MDI(z logu) vs MDI(z modelu):", np.abs(mdi_log - rf.feature_importances_).max())
perm, perm_err = permutation_importance_oob(rf, n_repeats=3)
plot_importances(names, mdi_log, perm, perm_err, top_k=15);
""")
code(r"""
top = list(np.argsort(-mdi_log)[:10])
plot_correlation(X_train, names, top);
""")

# ---------------------------------------------------------------------------
md(r"""
## 10. Wyjaśnienie pojedynczej predykcji

**Dekompozycja Saabasa** (*treeinterpreter*): wzdłuż ścieżki w drzewie każdy krok rodzic → dziecko zmienia $P(\text{złośliwy})$. Tę zmianę przypisujemy cesze, według której podzielono rodzica:
$$P_{\text{drzewo}}(x) = \underbrace{P(\text{korzeń})}_{\text{bias}} + \sum_{\text{kroki ścieżki}} \Delta P_{f}.$$
Uśredniając po drzewach dostajemy **dokładną** rozkładówkę predykcji lasu (bez przybliżeń):
$$P_{\text{las}}(x) = \overline{\text{bias}} + \sum_f \overline{\text{wkład}_f(x)}.$$
""")
code(src("explain", "tree_contributions", "forest_contributions", "path_table",
         "explain_prediction_text") + r"""


def explain_patient(i, n_paths=5, tree_to_draw=0):
    x = X_test[i]
    print(f"Pacjentka testowa #{i}, prawdziwa diagnoza: {D['class_names'][y_test[i]].upper()}\n")
    rf.predict_logged(x, tracer, sample_id=int(D['idx_test'][i]))
    print(explain_prediction_text(rf, x, names), "\n")
    bias, contrib, _, p = forest_contributions(rf, x)
    print(f"kontrola: bias + Σ wkładów = {p:.6f};  predict_proba = {rf.predict_proba(x[None])[0, 1]:.6f}")
    plot_tree_votes(rf.tree_probas(x[None])[:, 0, 1]); plt.show()
    plot_waterfall(bias, contrib, names, x); plt.show()
    display(pd.DataFrame(path_table(rf, x, max_trees=n_paths)))
    t = rf.trees_[tree_to_draw]
    plot_tree(t, names, max_depth=4, highlight_path=t.decision_path(x),
              title=f"Ścieżka pacjentki #{i} w drzewie #{tree_to_draw}"); plt.show()
""")
md("### 10.1 Przypadek jednoznaczny")
code(r"""
clear_case = int(np.argmax(np.where(y_test == 1, margins, -9)))   # złośliwy, największa zgodność drzew
explain_patient(clear_case)
""")
md("### 10.2 Przypadek niepewny — tu wyjaśnienie jest najcenniejsze")
code(r"""
hard_case = int(np.argmin(np.abs(p_rf - 0.5)))                     # P(złośliwy) najbliżej 0,5
explain_patient(hard_case)
""")
md("Zdarzenia `predict` także trafiły do dziennika:")
code(r"""
for e in tracer.filter("predict"):
    print({k: e[k] for k in ("sample_id", "proba", "predicted", "hard_votes", "vote_margin")})
""")

# ---------------------------------------------------------------------------
md(r"""
## 11. Dziennik jako ślad audytowy

Plik `rf_trace.jsonl` można wczytać niezależnie od modelu — np. żeby odpowiedzieć na pytanie *„w ilu drzewach i na jakiej głębokości użyto cechy X?”*.
""")
code(r"""
log = pd.read_json("rf_trace.jsonl", lines=True)
print(log["event"].value_counts().to_string(), "\n")
splits = log[log.event == "node_split"]
(splits.groupby("name")
       .agg(liczba_podziałów=("node_id", "size"), drzew=("tree_id", "nunique"),
            średnia_głębokość=("depth", "mean"), suma_ważonego_zysku=("weighted_gain", "sum"))
       .sort_values("suma_ważonego_zysku", ascending=False).head(10).round(3))
""")

md(r"""
## 12. Dlaczego (i kiedy) Random Forest?

**Za Random Forest na tych danych:**
* redukuje wariancję pojedynczego drzewa (sekcje 5 i 7) — stabilniejsze decyzje i wyższa czułość,
* daje **darmową walidację OOB** i ważność permutacyjną bez osobnego zbioru,
* nie wymaga skalowania cech i radzi sobie z nieliniowymi progami,
* każda decyzja jest **audytowalna**: dziennik + dekompozycja Saabasa.

**Uczciwie:** regresja logistyczna osiąga tu porównywalne (często lepsze) wyniki — ten zbiór jest prawie liniowo separowalny. Wybór modelu w medycynie powinien uwzględniać nie tylko AUC, ale też **kalibrację, interpretowalność i koszt błędów FN**. Las jest dobrym wyborem, gdy zależności są nieliniowe lub z interakcjami; prosty model liniowy — gdy wystarcza i jest łatwiejszy do wytłumaczenia klinicystom.

## Ćwiczenia
1. Ustaw `max_features=None` (czysty *bagging*). Jak zmienia się średnia niezgoda drzew, błąd OOB i rozkład cech w korzeniach?
2. Ustaw `max_features=1`. Drzewa są bardzo różne, ale słabe — co wygrywa?
3. Ogranicz `max_depth=3`. Porównaj wodospady Saabasa dla przypadku niepewnego.
4. Usuń z danych cechy `worst perimeter`, `worst radius`, `worst area` i porównaj ważność MDI z permutacyjną.
5. Dobierz próg decyzji tak, by czułość ≥ 0,98. Ile fałszywych alarmów to kosztuje?
""")

nb = nbf.v4.new_notebook()
nb.cells = cells
nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
nb.metadata["language_info"] = {"name": "python"}

if "--execute" in sys.argv:
    from nbclient import NotebookClient
    NotebookClient(nb, timeout=600, kernel_name="python3",
                   resources={"metadata": {"path": str(ROOT)}}).execute()

nbf.write(nb, OUT)
print("zapisano", OUT)
